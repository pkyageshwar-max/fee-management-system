<link rel="stylesheet" href="../assets/css/style.css">
<script src="../assets/js/app.js"></script>

<header>
    <h2>Fee Management System</h2>
    <a href="../auth/logout.php"
       class="logout-btn"
       onclick="return confirmLogout();">
        Logout
    </a>
</header>

<div class="container">
