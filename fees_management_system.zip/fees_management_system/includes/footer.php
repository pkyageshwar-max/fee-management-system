</div>

<footer>
    © <?php echo date("Y"); ?> Fee Management System
</footer>
