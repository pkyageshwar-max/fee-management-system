<?php
$conn = mysqli_connect("localhost","root","","fee_management_system");
if(!$conn){
    die("Database Connection Failed");
}
?>
