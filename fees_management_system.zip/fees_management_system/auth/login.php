<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>Fee Management Login</title>

<!-- ===== CSS ===== -->
<style>
body{
    margin:0;
    padding:0;
    font-family:"Segoe UI", Arial, sans-serif;
    background:linear-gradient(135deg,#2c3e50,#3498db);
    height:100vh;
    display:flex;
    justify-content:center;
    align-items:center;
}

/* LOGIN CARD */
.login-box{
    background:#ffffff;
    width:360px;
    padding:30px;
    border-radius:12px;
    box-shadow:0 12px 28px rgba(0,0,0,0.35);
    text-align:center;
}

/* COLLEGE HEADER */
.college-header{
    margin-bottom:20px;
}
.college-header img{
    height:70px;
    margin-bottom:10px;
}
.college-header h1{
    margin:0;
    font-size:20px;
    color:#2c3e50;
}
.college-header p{
    margin:3px 0 0;
    font-size:13px;
    color:#666;
}

/* FORM */
.login-box input{
    width:100%;
    padding:12px;
    margin:10px 0;
    border:1px solid #ccc;
    border-radius:6px;
    font-size:15px;
}

.login-box input:focus{
    outline:none;
    border-color:#3498db;
}

.login-box button{
    width:100%;
    padding:12px;
    background:#3498db;
    border:none;
    border-radius:6px;
    color:#fff;
    font-size:16px;
    cursor:pointer;
    transition:0.3s;
    margin-top:10px;
}

.login-box button:hover{
    background:#2980b9;
}

/* NOTE */
.note{
    margin-top:15px;
    font-size:13px;
    color:#777;
}
</style>
</head>

<body>

<div class="login-box">

    <!-- COLLEGE NAME & LOGO -->
    <div class="college-header">
        <img src="../assets/images/college_logo.png" alt="College Logo">
        <h1>Nanjiah Lingammal Polytechnic College</h1>
        <p>Fee Management System</p>
    </div>

    <!-- LOGIN FORM -->
    <form method="POST" action="login_action.php">
        <input type="text" name="username" placeholder="Username / Register No" required>
        <input type="password" name="password" placeholder="Password / Student ID" required>
        <button type="submit">Login</button>
    </form>

    <div class="note">
        Admin & Student Login Portal
    </div>

</div>

<!-- ===== JavaScript ===== -->
<script>
console.log("Login Page Loaded");
</script>

</body>
</html>
