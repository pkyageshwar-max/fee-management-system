<?php
session_start();
include "../config/db.php";

$user = $_POST['username'];
$pass = $_POST['password'];


/* ==========================
   ADMIN LOGIN
========================== */

if($user == "admin" && $pass == "admin123"){

    $_SESSION['role'] = "ADMIN";
    $_SESSION['username'] = "admin";

    header("Location: ../admin/dashboard.php");
    exit;
}


/* ==========================
   STUDENT LOGIN
========================== */

$q = mysqli_query($conn,"
SELECT student_id, reg_no
FROM students
WHERE reg_no='$user'
AND student_id='$pass'
");


if(mysqli_num_rows($q)==1){

$s = mysqli_fetch_assoc($q);

$_SESSION['role']="STUDENT";
$_SESSION['student_id']=$s['student_id'];
$_SESSION['reg_no']=$s['reg_no'];

header("Location: ../student/dashboard.php");
exit;

}

echo "Invalid Login";

?>