COURSE TABLE
INSERT INTO courses VALUES
('CSE','Computer Science Engineering',60,3,6,2019,'active'),
('ECE','Electronics & Communication',60,3,6,2018,'active'),
('EEE','Electrical & Electronics Engineering',60,3,6,2017,'active'),
('AUTO','Automobile Engineering',60,3,6,2016,'active'),
('AIML','Artificial Intelligence & ML',60,3,6,2022,'active');

ACADEMINC TABLE
INSERT INTO academic_periods VALUES
('2024-2025',1,1,'Odd','2024-06-15','2024-11-15'),
('2024-2025',2,1,'Even','2024-12-01','2025-04-15'),

('2025-2026',3,2,'Odd','2025-06-15','2025-11-15'),
('2025-2026',4,2,'Even','2025-12-01','2026-04-15'),

('2026-2027',5,3,'Odd','2026-06-15','2026-11-15'),
('2026-2027',6,3,'Even','2026-12-01','2027-04-15');
STUDENT TABLE
INSERT INTO students (
student_id, student_name, dob, gender, blood_group,
phone, email, address, course_code,
date_of_joining, batch_year, reg_no,
current_year, current_semester, hostel_required
) VALUES

-- ===== CSE =====
('CSE2401','Arun Kumar','2006-05-12','Male','O+','9876543201','arun@gmail.com','Chennai','CSE',
'2024-08-01','2024-2027',24001,1,1,'Yes'),

('CSE2402','Meena L','2006-02-11','Female','B+','9876543202','meena@gmail.com','Tiruppur','CSE',
'2024-08-01','2024-2027',24002,1,2,'No'),

('CSE2301','Divya Sri','2005-06-09','Female','A-','9876543203','divya@gmail.com','Coimbatore','CSE',
'2023-08-01','2023-2026',23001,2,3,'No'),

-- ===== ECE =====
('ECE2401','Pavithra S','2006-03-19','Female','AB-','9876543204','pavi@gmail.com','Ariyalur','ECE',
'2024-08-01','2024-2027',24011,1,1,'No'),

('ECE2301','Priya Devi','2005-01-22','Female','A+','9876543205','priya@gmail.com','Madurai','ECE',
'2023-08-01','2023-2026',23011,2,4,'No'),

('ECE2201','Anitha R','2004-09-30','Female','O-','9876543206','anitha@gmail.com','Namakkal','ECE',
'2022-08-01','2022-2025',22011,3,6,'No'),

-- ===== EEE =====
('EEE2401','Lokesh M','2006-07-22','Male','A+','9876543207','lokesh@gmail.com','Perambalur','EEE',
'2024-08-01','2024-2027',24021,1,1,'Yes'),

('EEE2301','Vijay Kumar','2005-11-02','Male','B-','9876543208','vijay@gmail.com','Vellore','EEE',
'2023-08-01','2023-2026',23021,2,3,'Yes'),

('EEE2201','Rahul Singh','2003-12-10','Male','B+','9876543209','rahul@gmail.com','Trichy','EEE',
'2022-08-01','2022-2025',22021,3,5,'Yes'),

-- ===== AUTOMOBILE =====
('AUTO2401','Harini P','2006-10-10','Female','O+','9876543210','harini@gmail.com','Thanjavur','AUTO',
'2024-08-01','2024-2027',24031,1,1,'No'),

('AUTO2301','Suresh B','2005-04-21','Male','A+','9876543211','suresh@gmail.com','Dharmapuri','AUTO',
'2023-08-01','2023-2026',23031,2,4,'Yes'),

('AUTO2201','Sneha Patel','2004-07-25','Female','O+','9876543212','sneha@gmail.com','Salem','AUTO',
'2022-08-01','2022-2025',22031,3,6,'No'),

-- ===== AIML =====
('AIML2401','Naveen K','2006-01-05','Male','O+','9876543213','naveen@gmail.com','Karur','AIML',
'2024-08-01','2024-2027',24041,1,1,'Yes'),

('AIML2301','Karthik Raja','2005-01-14','Male','AB+','9876543214','karthik@gmail.com','Erode','AIML',
'2023-08-01','2023-2026',23041,2,3,'Yes'),

('AIML2402','Ajith R','2006-12-01','Male','B+','9876543215','ajith@gmail.com','Nagapattinam','AIML',
'2024-08-01','2024-2027',24042,1,2,'Yes');