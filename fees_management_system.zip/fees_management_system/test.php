<?php

require "razorpay/Razorpay.php";

echo "Razorpay Connected Successfully";

?>