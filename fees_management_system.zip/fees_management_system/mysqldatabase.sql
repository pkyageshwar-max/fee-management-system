/* ================================
   FEE MANAGEMENT SYSTEM (FINAL)
   STUDENT-CENTRIC MODEL
   ================================ */

DROP DATABASE IF EXISTS fee_management_system;
CREATE DATABASE fee_management_system;
USE fee_management_system;

/* ================================
   COURSES
   ================================ */
CREATE TABLE courses (
    course_code VARCHAR(20) PRIMARY KEY,
    course_name VARCHAR(50) NOT NULL,
    approved_intake INT NOT NULL, 
    duration_years INT NOT NULL,
    total_semesters INT NOT NULL,
    year_of_established INT NOT NULL,
    status ENUM('active', 'inactive') DEFAULT 'active'
);

/* ================================
   ACADEMIC PERIODS
   ================================ */
CREATE TABLE academic_periods (
    academic_year VARCHAR(9) NOT NULL,
    semester_number INT NOT NULL,
    study_year INT NOT NULL,
    semester_type ENUM('Odd','Even') NOT NULL,
    start_date DATE NOT NULL,
    end_date DATE NOT NULL,
    PRIMARY KEY (academic_year, semester_number)
);

/* ================================
   STUDENTS 
   ================================ */
CREATE TABLE students (
    student_id VARCHAR(20) PRIMARY KEY,
    student_name VARCHAR(30) NOT NULL,
    dob DATE NOT NULL,

    mother_tongue VARCHAR(20),
    gender ENUM('Male', 'Female'),
    religion VARCHAR(20),
    community VARCHAR(20),
    caste VARCHAR(30),

    aadhar_no CHAR(12) UNIQUE,
    umis_no VARCHAR(20) UNIQUE,
    emis_no VARCHAR(20) UNIQUE,

    blood_group ENUM('A+','A-','B+','B-','O+','O-','AB+','AB-'),
    phone VARCHAR(10),
    email VARCHAR(50),
    address TEXT,
    student_photo VARCHAR(255),

    course_code VARCHAR(20) NOT NULL,
    date_of_joining DATE NOT NULL,
    batch_year VARCHAR(9) NOT NULL,
    reg_no BIGINT NOT NULL UNIQUE,

    current_year INT DEFAULT 1,
    current_semester INT DEFAULT 1,

    last_login DATETIME,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  hostel_required ENUM('Yes','No') NOT NULL DEFAULT 'No',
  transport_required ENUM('Yes','No') NOT NULL DEFAULT 'No'

FOREIGN KEY (course_code) REFERENCES courses(course_code)
);

/* ================================
   FEE HEAD
   ================================ */
CREATE TABLE fee_head (
    head_id INT AUTO_INCREMENT PRIMARY KEY,
    fee_code VARCHAR(20) UNIQUE,
    head_name VARCHAR(100) NOT NULL,
    default_amount DECIMAL(10,2) DEFAULT 0
);



INSERT INTO fee_head (head_name) VALUES
('Tuition Fee'),
('Exam Fee'),
('Bus Fee'),
('Library Fee'),
('Miscellaneous');

/* ================================
   FEE STRUCTURE DETAIL
   ================================ */
CREATE TABLE fee_structure_detail (
    fsd_id INT AUTO_INCREMENT PRIMARY KEY,
    course VARCHAR(20),
    academic_year INT,
    semester INT,
    head_id INT,
    amount DECIMAL(10,2),
    FOREIGN KEY (head_id) REFERENCES fee_head(head_id)
);

/* ================================
   PAYMENT
   ================================ */
CREATE TABLE payment (
    payment_id INT AUTO_INCREMENT PRIMARY KEY,
    student_id VARCHAR(20) NOT NULL,

    tuition_paid DECIMAL(10,2) DEFAULT 0,
    exam_paid DECIMAL(10,2) DEFAULT 0,
    hostel_paid DECIMAL(10,2) DEFAULT 0,
    total_amount DECIMAL(10,2) NOT NULL,

    payment_mode VARCHAR(50),
    transaction_id VARCHAR(100),
    receipt_no VARCHAR(50),
    payment_date DATE,
  status ENUM('Pending','Paid','Failed'),

    FOREIGN KEY (student_id)
        REFERENCES students(student_id)
        ON DELETE CASCADE
);

/* ================================
   CONCESSION
   ================================ */
CREATE TABLE concession (
    concession_id INT AUTO_INCREMENT PRIMARY KEY,
    student_id VARCHAR(20) NOT NULL,

    concession_type VARCHAR(100),
    concession_amount DECIMAL(10,2),
    approved_by VARCHAR(100),
    approved_date DATE,

    FOREIGN KEY (student_id)
        REFERENCES students(student_id)
        ON DELETE CASCADE
);

/* ================================
   FINE
   ================================ */
CREATE TABLE fine (
    fine_id INT AUTO_INCREMENT PRIMARY KEY,
    student_id VARCHAR(20) NOT NULL,

    fine_reason VARCHAR(200),
    fine_amount DECIMAL(10,2),
    fine_date DATE,
   status ENUM('Unpaid','Paid'),

    FOREIGN KEY (student_id)
        REFERENCES students(student_id)
        ON DELETE CASCADE
);

/* ================================
   SMS LOG
   ================================ */
CREATE TABLE smslog (
    sms_id INT AUTO_INCREMENT PRIMARY KEY,
    student_id VARCHAR(20) NOT NULL,

    phone_no VARCHAR(15),
    message TEXT,
    status VARCHAR(20),
    sent_time DATETIME DEFAULT CURRENT_TIMESTAMP,

    FOREIGN KEY (student_id)
        REFERENCES students(student_id)
        ON DELETE CASCADE
);

/* ================================
   REPORT
   ================================ */
CREATE TABLE report (
    report_id INT AUTO_INCREMENT PRIMARY KEY,
    payment_id INT NOT NULL,
    student_id VARCHAR(20),

    receipt_no VARCHAR(50),
    student_name VARCHAR(100),
    course VARCHAR(100),
    amount DECIMAL(10,2),
    payment_status VARCHAR(20),
    date DATE,
    approved_by VARCHAR(100),

    FOREIGN KEY (payment_id) REFERENCES payment(payment_id) ON DELETE CASCADE,
    FOREIGN KEY (student_id) REFERENCES students(student_id) ON DELETE SET NULL
);


/* ================================
   HOSTEL
   ================================ */
CREATE TABLE hostel (
  hostel_id INT PRIMARY KEY,
  student_id VARCHAR(20),
  student_name VARCHAR(100),
  register_no VARCHAR(30),
  department VARCHAR(50),
  block VARCHAR(20),
  room_no VARCHAR(10),
  bed_no VARCHAR(10),
  fee_amount DECIMAL(10,2),
  fee_status VARCHAR(20),
  FOREIGN KEY (student_id) REFERENCES students(student_id)
);

/* ================================
   TRANSPORT
   ================================ */
CREATE TABLE transport (
  transport_id INT PRIMARY KEY,
  driver_name VARCHAR(100),
  driver_contact VARCHAR(15),
  route_name VARCHAR(100),
  start_point VARCHAR(100),
  end_point VARCHAR(100),
  vehicle_no VARCHAR(20) UNIQUE,
  capacity INT,
  status VARCHAR(20)
);
/* ================================
   Hostel Monthly Fee (Admin Feed)
   ================================ */
   CREATE TABLE hostel_monthly_admin (
    hostel_monthly_id INT AUTO_INCREMENT PRIMARY KEY,

    student_id VARCHAR(20),
    hostel_id INT,

    bill_month VARCHAR(20),
    no_of_days INT,
    per_day_rate DECIMAL(10,2),
    total_amount DECIMAL(10,2),

    status ENUM('Pending','Paid') DEFAULT 'Pending',

    FOREIGN KEY (student_id) REFERENCES students(student_id),
    FOREIGN KEY (hostel_id) REFERENCES hostel(hostel_id)
);
/* ================================
   Transport Monthly Fee (Admin Feed)                            NOT USING STAGE IN THIS TABLE
   ================================ */
   CREATE TABLE transport_monthly_admin (
    transport_monthly_id INT AUTO_INCREMENT PRIMARY KEY,

    student_id VARCHAR(20),
    transport_id INT,

    bill_month VARCHAR(20),
    monthly_fee DECIMAL(10,2),

    status ENUM('Pending','Paid') DEFAULT 'Pending',

    FOREIGN KEY (student_id) REFERENCES students(student_id),
    FOREIGN KEY (transport_id) REFERENCES transport(transport_id)
);
/* ================================
   Transport Fee Assign (Admin Feed)                           
   ================================ */
   CREATE TABLE transport_fee_assign (
    transport_fee_id INT AUTO_INCREMENT PRIMARY KEY,

    student_id VARCHAR(20) NOT NULL,
    transport_id INT NOT NULL,

    transport_fee DECIMAL(10,2),   -- e.g. 5000
    status ENUM('Pending','Paid') DEFAULT 'Pending',

    FOREIGN KEY (student_id) REFERENCES students(student_id),
    FOREIGN KEY (transport_id) REFERENCES transport(transport_id)
);
/* ================================
   Hostel ASSIGN
   ================================ */
   CREATE TABLE hostel_fee_assign (
    hostel_fee_id INT AUTO_INCREMENT PRIMARY KEY,
    student_id VARCHAR(20) NOT NULL,
    head_id INT NOT NULL,
    amount DECIMAL(10,2) NOT NULL,

    FOREIGN KEY (student_id) REFERENCES students(student_id),
    FOREIGN KEY (head_id) REFERENCES fee_head(head_id)
);
