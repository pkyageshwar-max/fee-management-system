<?php
session_start();
if($_SESSION['role']!='ADMIN') die("Access Denied");
include "../config/db.php";

if(isset($_POST['create'])){
    $sid  = $_POST['student_id'];
    $year = $_POST['year'];
    $sem  = $_POST['sem'];

    // Prevent duplicate session
    $check = mysqli_query($conn,"
      SELECT * FROM student_session
      WHERE student_id=$sid AND academic_year=$year AND semester=$sem
    ");

    if(mysqli_num_rows($check)==0){
        mysqli_query($conn,"
          INSERT INTO student_session (student_id, academic_year, semester)
          VALUES ($sid, $year, $sem)
        ");
        echo "Session Created Successfully";
    } else {
        echo "Session Already Exists";
    }
}
?>

<h3>Create Student Session</h3>
<form method="POST">
<input name="student_id" placeholder="Student ID" required>
<input name="year" placeholder="Academic Year" required>
<input name="sem" placeholder="Semester" required>
<button name="create">Create Session</button>
</form>
<a href="../auth/logout.php"
   onclick="return confirm('Logout?')">
   Logout
</a>

