<?php
include "../config/db.php";

/* ------------ FILTERS ------------ */

$course=$_GET['course'] ?? '';
$year=$_GET['year'] ?? '';
$sem=$_GET['sem'] ?? '';

$where="WHERE 1=1";

if($course!=''){
$where.=" AND s.course_code='".mysqli_real_escape_string($conn,$course)."'";
}

if($year!=''){
$where.=" AND s.current_year=".(int)$year;
}

if($sem!=''){
$where.=" AND s.current_semester=".(int)$sem;
}

$printMode = isset($_GET['print']);
?>
<!DOCTYPE html>
<html>
<head>

<title>Fee History Report</title>

<style>

body{
margin:0;
font-family:Segoe UI;
background:#f4f6f9;
}

.container{
padding:30px;
}

.card{
background:white;
padding:20px;
border-radius:8px;
box-shadow:0 2px 6px rgba(0,0,0,.1);
margin-bottom:20px;
}

.top-bar{
display:flex;
justify-content:space-between;
align-items:center;
margin-bottom:15px;
}

.print-btn{

background:#2563eb;
color:white;
border:none;
padding:10px 16px;
border-radius:6px;
cursor:pointer;
font-weight:bold;

}

.download-btn{

background:#16a34a;
color:white;
border:none;
padding:10px 16px;
border-radius:6px;
cursor:pointer;
font-weight:bold;

}

select,button{

padding:8px;
border-radius:5px;
border:1px solid #ccc;

}

table{

width:100%;
border-collapse:collapse;
font-size:13px;

}

th{

background:#2c3e50;
color:white;
padding:8px;

}

td{

padding:8px;
border:1px solid #ddd;
text-align:center;

}

.status-paid{

color:green;
font-weight:bold;

}

.status-pending{

color:red;
font-weight:bold;

}

/* PRINT MODE */

@media print{

body{

background:white;

}

.top-bar,
.filter-card,
.back{

display:none!important;

}

th{

background:#eee!important;
color:black!important;

}

}

.header{

text-align:center;
margin-bottom:15px;

}

.header h3{

margin:0;

}

</style>

</head>

<body>

<div class="container">

<div class="top-bar">

<h2>Overall Fee History Report</h2>

<div>

<button onclick="window.print()" class="print-btn">

🖨 Print

</button>


<a href="?course=<?=$course?>&year=<?=$year?>&sem=<?=$sem?>&print=1" target="_blank">

<button class="download-btn">

⬇ Printable View

</button>

</a>

</div>

</div>


<!-- PRINT HEADER -->

<div class="card header">

<h3>NANJIAH LINGAMMAL POLYTECHNIC COLLEGE</h3>

Fee History Report

<br>

Printed On :

<?=date("d-m-Y")?>

</div>



<!-- FILTER -->

<?php if(!$printMode){ ?>

<div class="card filter-card">

<form method="GET">

Course :

<select name="course">

<option value="">All</option>

<?php

$c=mysqli_query($conn,"
SELECT DISTINCT course_code
FROM students
ORDER BY course_code
");

while($r=mysqli_fetch_assoc($c)){

$sel=$course==$r['course_code']?"selected":"";

echo"<option value='{$r['course_code']}' $sel>{$r['course_code']}</option>";

}

?>

</select>


Year :

<select name="year">

<option value="">All</option>

<?php

for($i=1;$i<=4;$i++){

$sel=$year==$i?"selected":"";

echo"<option value='$i' $sel>$i</option>";

}

?>

</select>


Semester :

<select name="sem">

<option value="">All</option>

<?php

for($i=1;$i<=8;$i++){

$sel=$sem==$i?"selected":"";

echo"<option value='$i' $sel>$i</option>";

}

?>

</select>

<button type="submit">

Filter

</button>

</form>

</div>

<?php } ?>


<div class="card">

<table>

<tr>

<th>Student</th>
<th>Course</th>
<th>Year</th>
<th>Sem</th>
<th>Total Fee</th>
<th>Concession</th>
<th>Fine</th>
<th>Payable</th>
<th>Paid</th>
<th>Pending</th>
<th>Status</th>

</tr>

<?php

$q=mysqli_query($conn,"

SELECT

s.student_name,
s.course_code,
s.current_year,
s.current_semester,

IFNULL(SUM(fs.amount),0) total_fee,

IFNULL(SUM(c.concession_amount),0) concession,

IFNULL(SUM(f.fine_amount),0) fine,

IFNULL(SUM(p.total_amount),0) paid_amount

FROM students s

LEFT JOIN fee_structure_detail fs
ON fs.course=s.course_code
AND fs.academic_year=s.current_year
AND fs.semester=s.current_semester

LEFT JOIN concession c
ON c.student_id=s.student_id

LEFT JOIN fine f
ON f.student_id=s.student_id
AND f.status='UNPAID'

LEFT JOIN payment p
ON p.student_id=s.student_id
AND p.status='Paid'

$where

GROUP BY s.student_id

ORDER BY s.student_name

");

while($r=mysqli_fetch_assoc($q)){

$payable=$r['total_fee']-$r['concession']+$r['fine'];

$pending=$payable-$r['paid_amount'];

$status=$pending<=0?"PAID":"PENDING";

?>

<tr>

<td><?=$r['student_name']?></td>

<td><?=$r['course_code']?></td>

<td><?=$r['current_year']?></td>

<td><?=$r['current_semester']?></td>

<td>₹<?=number_format($r['total_fee'],2)?></td>

<td>-₹<?=number_format($r['concession'],2)?></td>

<td>+₹<?=number_format($r['fine'],2)?></td>

<td><b>₹<?=number_format($payable,2)?></b></td>

<td>₹<?=number_format($r['paid_amount'],2)?></td>

<td><b>₹<?=number_format($pending,2)?></b></td>

<td>

<?php if($status=="PAID"){ ?>

<span class="status-paid">PAID</span>

<?php } else { ?>

<span class="status-pending">PENDING</span>

<?php } ?>

</td>

</tr>

<?php } ?>

</table>

</div>

<a class="back" href="dashboard.php">

⬅ Back Dashboard

</a>

</div>

</body>

</html>