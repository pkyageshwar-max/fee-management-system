<?php
session_start();
if($_SESSION['role']!='ADMIN') die("Access Denied");

include "../config/db.php";

$msg = "";
$error = "";

/* ===============================
   SAVE TRANSPORT DATA
================================ */
if(isset($_POST['save'])){

    $driver_name    = $_POST['driver_name'];
    $driver_contact = $_POST['driver_contact'];
    $route_name     = $_POST['route_name'];
    $start_point    = $_POST['start_point'];
    $end_point      = $_POST['end_point'];
    $vehicle_no     = $_POST['vehicle_no'];
    $capacity       = (int)$_POST['capacity'];

    /* Check duplicate vehicle number */
    $check = mysqli_query($conn,"
        SELECT transport_id FROM transport 
        WHERE vehicle_no = '$vehicle_no'
    ");

    if(mysqli_num_rows($check)==0){

        mysqli_query($conn,"
            INSERT INTO transport
            (driver_name, driver_contact, route_name, start_point, end_point,
             vehicle_no, capacity, status, created_at)
            VALUES
            ('$driver_name','$driver_contact','$route_name','$start_point',
             '$end_point','$vehicle_no',$capacity,'Active',NOW())
        ");

        $msg = "✅ Transport route added successfully";

    } else {
        $error = "⚠️ Vehicle number already exists";
    }
}

/* ===============================
   FETCH TRANSPORT LIST
================================ */
$list = mysqli_query($conn,"
    SELECT * FROM transport ORDER BY transport_id DESC
");
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>Transport Management | Admin</title>

<style>
body{
    margin:0;
    font-family:"Segoe UI", Arial, sans-serif;
    background:#f4f6f9;
}
.container{
    padding:30px;
    max-width:1000px;
    margin:auto;
}
h2,h3{ color:#2c3e50; }

.card{
    background:#fff;
    padding:25px;
    border-radius:8px;
    box-shadow:0 2px 6px rgba(0,0,0,0.1);
    margin-bottom:25px;
}

form{
    display:grid;
    grid-template-columns:1fr 1fr;
    gap:15px;
}
form label{
    grid-column:span 2;
    font-weight:600;
}
form input{
    padding:10px;
    border:1px solid #ccc;
    border-radius:5px;
    grid-column:span 2;
}

.row2 input{ grid-column:span 1; }

button{
    grid-column:span 2;
    padding:12px;
    background:#2980b9;
    border:none;
    color:#fff;
    border-radius:5px;
    font-size:15px;
    cursor:pointer;
}
button:hover{ background:#1f6691; }

.success{
    background:#e8f7ee;
    color:#1e8449;
    padding:10px;
    border-radius:5px;
    margin-bottom:10px;
}
.error{
    background:#fdecea;
    color:#c0392b;
    padding:10px;
    border-radius:5px;
    margin-bottom:10px;
}

table{
    width:100%;
    border-collapse:collapse;
}
th{
    background:#2c3e50;
    color:white;
    padding:10px;
}
td{
    padding:9px;
    border:1px solid #ddd;
    text-align:center;
}

.back{
    display:inline-block;
    margin-top:20px;
    text-decoration:none;
    color:#3498db;
    font-weight:bold;
}
.back:hover{ text-decoration:underline; }
</style>
</head>

<body>

<div class="container">

<h2>🚌 Transport Management</h2>

<div class="card">
<h3>Add Transport Route</h3>

<?php if($msg!=""): ?><div class="success"><?= $msg ?></div><?php endif; ?>
<?php if($error!=""): ?><div class="error"><?= $error ?></div><?php endif; ?>

<form method="POST">

<label>Driver Name</label>
<input type="text" name="driver_name" required>

<label>Driver Contact</label>
<input type="text" name="driver_contact" required>

<label>Route Name</label>
<input type="text" name="route_name" required>

<label>Start Point</label>
<input type="text" name="start_point" required>

<label>End Point</label>
<input type="text" name="end_point" required>

<label>Vehicle Number</label>
<input type="text" name="vehicle_no" required>

<label>Vehicle Capacity</label>
<input type="number" name="capacity" required>

<button name="save">Save Transport</button>

</form>
</div>

<div class="card">
<h3>📋 Transport Route List</h3>

<table>
<tr>
<th>Route</th>
<th>Start</th>
<th>End</th>
<th>Vehicle No</th>
<th>Driver</th>
<th>Contact</th>
<th>Capacity</th>
<th>Status</th>
</tr>

<?php while($r=mysqli_fetch_assoc($list)){ ?>
<tr>
<td><?= $r['route_name'] ?></td>
<td><?= $r['start_point'] ?></td>
<td><?= $r['end_point'] ?></td>
<td><?= $r['vehicle_no'] ?></td>
<td><?= $r['driver_name'] ?></td>
<td><?= $r['driver_contact'] ?></td>
<td><?= $r['capacity'] ?></td>
<td><?= $r['status'] ?></td>
</tr>
<?php } ?>

</table>
</div>

<a href="/fees_management_system/admin/dashboard.php">
⬅ Back to Dashboard
</a>


</div>

</body>
</html>
