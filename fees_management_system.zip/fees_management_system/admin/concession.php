<?php
session_start();
if($_SESSION['role']!='ADMIN') die("Access Denied");
include "../config/db.php";

/* ---------- ADD CONCESSION ---------- */
if(isset($_POST['add'])){
    $student_id = mysqli_real_escape_string($conn, $_POST['student_id']);
    $type  = mysqli_real_escape_string($conn, $_POST['type']);
    $amt   = (float)$_POST['amount'];
    $by    = "Admin";

    mysqli_query($conn,"
        INSERT INTO concession
        (student_id, concession_type, concession_amount, approved_by, approved_date)
        VALUES
        ('$student_id','$type',$amt,'$by',CURDATE())
    ") or die(mysqli_error($conn));

    $msg = "Concession Added Successfully";
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>Concession | Admin</title>

<style>
body{margin:0;font-family:"Segoe UI",Arial,sans-serif;background:#f4f6f9}
.container{padding:30px}
h2,h3{color:#2c3e50}
.card{background:#fff;padding:20px;border-radius:8px;box-shadow:0 2px 6px rgba(0,0,0,.1);margin-bottom:25px}
form{display:grid;grid-template-columns:repeat(auto-fit,minmax(200px,1fr));gap:15px}
form input{padding:10px;border:1px solid #ccc;border-radius:5px}
form button{grid-column:1/-1;padding:12px;background:#27ae60;border:none;color:#fff;border-radius:5px;font-size:15px;cursor:pointer}
form button:hover{background:#219150}
.success{color:green;font-weight:bold;margin-bottom:10px}
table{width:100%;border-collapse:collapse;background:#fff}
table th{background:#2c3e50;color:#fff;padding:10px}
table td{padding:10px;border:1px solid #ddd;text-align:center}
.back{display:inline-block;margin-top:20px;text-decoration:none;color:#3498db;font-weight:bold}
.back:hover{text-decoration:underline}
</style>
</head>

<body>

<div class="container">

<h2>Concession Management</h2>

<div class="card">
<h3>Add Concession</h3>

<?php if(isset($msg)): ?>
<p class="success"><?= $msg ?></p>
<?php endif; ?>

<form method="POST">
    <input type="text" name="student_id" placeholder="Student ID (eg: CSE2301)" required>
    <input type="text" name="type" placeholder="Concession Type (eg: SC / Sports)" required>
    <input type="number" name="amount" placeholder="Amount" required>
    <button name="add">Save Concession</button>
</form>
</div>

<div class="card">
<h3>Concession List</h3>

<table>
<tr>
    <th>Student Name</th>
    <th>Course</th>
    <th>Year</th>
    <th>Semester</th>
    <th>Concession Type</th>
    <th>Amount</th>
    <th>Approved By</th>
    <th>Date</th>
</tr>

<?php
$q = mysqli_query($conn,"
SELECT 
    s.student_name,
    s.course_code,
    s.current_year,
    s.current_semester,
    c.concession_type,
    c.concession_amount,
    c.approved_by,
    c.approved_date
FROM concession c
JOIN students s ON c.student_id = s.student_id
ORDER BY c.concession_id DESC
") or die(mysqli_error($conn));

if(mysqli_num_rows($q)==0){
  echo "<tr><td colspan='8'>No concessions found</td></tr>";

}

while($r = mysqli_fetch_assoc($q)){
?>
<tr>
<td><?= htmlspecialchars($r['student_name']) ?></td>
<td><?= htmlspecialchars($r['course_code']) ?></td>
<td><?= $r['current_year'] ?></td>
<td><?= $r['current_semester'] ?></td>
<td><?= htmlspecialchars($r['concession_type']) ?></td>
<td>₹<?= $r['concession_amount'] ?></td>
<td><?= htmlspecialchars($r['approved_by']) ?></td>
<td><?= $r['approved_date'] ?></td>
</tr>
<?php } ?>
</table>
</div>

<a href="/fees_management_system/admin/dashboard.php">
⬅ Back to Dashboard
</a>


</div>

</body>
</html>
