<?php
session_start();
if($_SESSION['role'] != 'ADMIN') die("Access Denied");
include "../config/db.php";

/* ---------- Filters ---------- */
$search   = $_GET['search'] ?? '';
$course   = $_GET['course'] ?? '';
$year     = $_GET['year'] ?? '';
$semester = $_GET['semester'] ?? '';
$sort     = $_GET['sort'] ?? 'date_desc';

/* ---------- Sorting ---------- */
$orderBy = "p.payment_date DESC";
if($sort == 'date_asc')    $orderBy = "p.payment_date ASC";
if($sort == 'amount_asc')  $orderBy = "p.total_amount ASC";
if($sort == 'amount_desc') $orderBy = "p.total_amount DESC";

/* ---------- WHERE conditions ---------- */
$where = "WHERE 1";

if($search != ''){
    $s = mysqli_real_escape_string($conn, $search);
    $where .= " AND (
        s.student_name LIKE '%$s%' OR
        p.receipt_no LIKE '%$s%' OR
        p.transaction_id LIKE '%$s%'
    )";
}

if($course != '')   
    $where .= " AND s.course_code = '".mysqli_real_escape_string($conn,$course)."'";

if($year != '')     
    $where .= " AND s.current_year = ".(int)$year;

if($semester != '') 
    $where .= " AND s.current_semester = ".(int)$semester;
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>Payments | Admin</title>

<style>
body{
    margin:0;
    font-family:"Segoe UI", Arial, sans-serif;
    background:#f4f6f9;
}
.container{padding:30px}
h2{color:#2c3e50}
.card{
    background:#fff;padding:20px;border-radius:8px;
    box-shadow:0 2px 6px rgba(0,0,0,0.1);margin-bottom:20px
}
.filter-form{
    display:grid;
    grid-template-columns:repeat(auto-fit,minmax(180px,1fr));
    gap:10px;align-items:end
}
.filter-form input,.filter-form select{
    padding:10px;border:1px solid #ccc;border-radius:5px
}
.filter-form button{
    padding:10px;background:#3498db;border:none;color:#fff;
    border-radius:5px;cursor:pointer
}
.filter-form button:hover{background:#2980b9}
.filter-form a{
    display:inline-block;padding:10px;text-align:center;
    background:#95a5a6;color:#fff;border-radius:5px;text-decoration:none
}
.filter-form a:hover{background:#7f8c8d}
table{width:100%;border-collapse:collapse;background:#fff}
table th{background:#2c3e50;color:#fff;padding:10px}
table td{padding:10px;border:1px solid #ddd;text-align:center}
.status-success{color:green;font-weight:bold}
.status-fail{color:red;font-weight:bold}
.back{
    display:inline-block;margin-top:20px;text-decoration:none;
    color:#3498db;font-weight:bold
}
.back:hover{text-decoration:underline}
</style>
</head>

<body>

<div class="container">

<h2>Payment Records</h2>

<div class="card">
<form method="GET" class="filter-form">
    <input type="text" name="search" placeholder="Search name / receipt / txn"
           value="<?= htmlspecialchars($search) ?>">

    <input type="text" name="course" placeholder="Course"
           value="<?= htmlspecialchars($course) ?>">

    <input type="number" name="year" placeholder="Year"
           value="<?= htmlspecialchars($year) ?>">

    <input type="number" name="semester" placeholder="Semester"
           value="<?= htmlspecialchars($semester) ?>">

    <select name="sort">
        <option value="date_desc"   <?= $sort=='date_desc'?'selected':'' ?>>Newest First</option>
        <option value="date_asc"    <?= $sort=='date_asc'?'selected':'' ?>>Oldest First</option>
        <option value="amount_desc" <?= $sort=='amount_desc'?'selected':'' ?>>Amount High → Low</option>
        <option value="amount_asc"  <?= $sort=='amount_asc'?'selected':'' ?>>Amount Low → High</option>
    </select>

    <button type="submit">Filter</button>
    <a href="payments.php">Reset</a>
</form>
</div>

<div class="card">
<table>
<tr>
    <th>Receipt No</th>
    <th>Student Name</th>
    <th>Course</th>
    <th>Year</th>
    <th>Semester</th>
    <th>Amount</th>
    <th>Mode</th>
    <th>Transaction</th>
    <th>Date</th>
    <th>Status</th>
</tr>

<?php
$sql = "
SELECT
    p.receipt_no,
    s.student_name,
    s.course_code,
    s.current_year,
    s.current_semester,
    p.total_amount,
    p.payment_mode,
    p.transaction_id,
    p.payment_date,
    p.status
FROM payment p
JOIN students s ON p.student_id = s.student_id
$where
ORDER BY $orderBy
";

$q = mysqli_query($conn,$sql) or die(mysqli_error($conn));

if(mysqli_num_rows($q) == 0){
    echo "<tr><td colspan='10'>No payments found</td></tr>";
}

while($r = mysqli_fetch_assoc($q)){
?>
<tr>
<td><?= htmlspecialchars($r['receipt_no']) ?></td>
<td><?= htmlspecialchars($r['student_name']) ?></td>
<td><?= htmlspecialchars($r['course_code']) ?></td>
<td><?= $r['current_year'] ?></td>
<td><?= $r['current_semester'] ?></td>
<td>₹<?= $r['total_amount'] ?></td>
<td><?= htmlspecialchars($r['payment_mode']) ?></td>
<td><?= htmlspecialchars($r['transaction_id']) ?></td>
<td><?= $r['payment_date'] ?></td>
<td><?= $r['status'] ?></td>
</tr>
<?php } ?>
</table>
</div>

<a href="/fees_management_system/admin/dashboard.php">
⬅ Back to Dashboard
</a>


</div>

</body>
</html>
