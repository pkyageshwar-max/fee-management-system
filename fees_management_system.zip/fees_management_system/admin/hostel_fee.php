<?php
session_start();
if($_SESSION['role']!='ADMIN') die("Access Denied");

include "../config/db.php";

$msg = "";
$error = "";

/* ===============================
   FETCH STUDENTS (EXISTING)
================================ */
$students = mysqli_query($conn,"
    SELECT student_id, student_name, reg_no, course_code, current_year, current_semester
    FROM students
    ORDER BY student_name
");

/* ===============================
   HOSTEL AVAILABILITY (NEW)
================================ */

// total students opted for hostel
$totalHostelRequired = mysqli_fetch_assoc(mysqli_query($conn,"
    SELECT COUNT(*) AS total 
    FROM students 
    WHERE hostel_required='Yes'
"))['total'];

// total students already assigned hostel
$totalHostelAssigned = mysqli_fetch_assoc(mysqli_query($conn,"
    SELECT COUNT(DISTINCT student_id) AS total 
    FROM hostel
"))['total'];

// available hostel students (not yet assigned)
$availableHostelStudents = mysqli_query($conn,"
    SELECT s.student_id, s.student_name, s.reg_no, s.course_code
    FROM students s
    WHERE s.hostel_required='Yes'
    AND s.student_id NOT IN (SELECT student_id FROM hostel)
    ORDER BY s.student_name
");

/* ===============================
   SAVE HOSTEL FEE (EXISTING)
================================ */
if(isset($_POST['save'])){

    $student_id = mysqli_real_escape_string($conn, $_POST['student_id']);
    $fee = (float)$_POST['hostel_fee'];

    $get = mysqli_fetch_assoc(mysqli_query($conn,"
        SELECT student_name, reg_no, course_code, current_year, current_semester
        FROM students
        WHERE student_id = '$student_id'
    "));

    $check = mysqli_query($conn,"
        SELECT hostel_id FROM hostel 
        WHERE student_id = '$student_id'
    ");

    if(mysqli_num_rows($check)==0){

        mysqli_query($conn,"
            INSERT INTO hostel
            (student_id, student_name, register_no, department, block, room_no, bed_no, fee_amount, fee_status)
            VALUES
            ('$student_id','{$get['student_name']}','{$get['reg_no']}','{$get['course_code']}',
             'A Block','101','1',$fee,'PENDING')
        ") or die(mysqli_error($conn));

        $msg = "✅ Hostel fee assigned successfully";

    } else {
        $error = "⚠️ Hostel record already exists for this student";
    }
}

/* ===============================
   LIST HOSTEL FEES
================================ */
$list = mysqli_query($conn,"
    SELECT * FROM hostel ORDER BY hostel_id DESC
");

/* ===============================
   LIST HOSTEL FEES
================================ */
$list = mysqli_query($conn,"
    SELECT * FROM hostel ORDER BY hostel_id DESC
");
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>Hostel Fee | Admin</title>

<style>
body{margin:0;font-family:"Segoe UI", Arial, sans-serif;background:#f4f6f9;}
.container{padding:30px;max-width:950px;margin:auto;}
h2,h3{color:#2c3e50;}
.card{background:#fff;padding:25px;border-radius:8px;
      box-shadow:0 2px 6px rgba(0,0,0,0.1);margin-bottom:25px;}
form{display:grid;gap:15px;}
label{font-weight:600;}
input,select{padding:10px;border:1px solid #ccc;border-radius:5px;}
button{padding:12px;background:#8e44ad;border:none;color:#fff;
       border-radius:5px;font-size:15px;cursor:pointer;}
button:hover{background:#732d91;}
.success{background:#e8f7ee;color:#1e8449;padding:10px;border-radius:5px;margin-bottom:10px;}
.error{background:#fdecea;color:#c0392b;padding:10px;border-radius:5px;margin-bottom:10px;}
table{width:100%;border-collapse:collapse;background:#fff;}
th{background:#2c3e50;color:white;padding:10px;}
td{padding:9px;border:1px solid #ddd;text-align:center;}
.back{display:inline-block;margin-top:20px;text-decoration:none;color:#3498db;font-weight:bold;}
.back:hover{text-decoration:underline;}
</style>
</head>

<body>

<div class="container">

<h2> Hostel Fee Management</h2>
<div class="card">
<h3> Hostel Availability Status</h3>

<p><b>Total Students Opted for Hostel:</b> <?= $totalHostelRequired ?></p>
<p><b>Students Already Assigned Hostel:</b> <?= $totalHostelAssigned ?></p>
<p><b>Students Available for Hostel:</b> <?= mysqli_num_rows($availableHostelStudents) ?></p>

<table style="margin-top:15px;">
<tr>
    <th>Register No</th>
    <th>Student Name</th>
    <th>Department</th>
</tr>

<?php
if(mysqli_num_rows($availableHostelStudents)>0){
while($a = mysqli_fetch_assoc($availableHostelStudents)){
?>
<tr>
    <td><?= $a['reg_no'] ?></td>
    <td><?= $a['student_name'] ?></td>
    <td><?= $a['course_code'] ?></td>
</tr>
<?php }} else { ?>
<tr>
    <td colspan="3" style="color:green;text-align:center;">
        🎉 All hostel-required students are already assigned.
    </td>
</tr>
<?php } ?>
</table>
</div>
<div class="card">
<h3>Assign Hostel Fee</h3>

<?php if($msg!=""): ?><div class="success"><?= $msg ?></div><?php endif; ?>
<?php if($error!=""): ?><div class="error"><?= $error ?></div><?php endif; ?>

<form method="POST">

<label>Select Student</label>
<select name="student_id" required>
<option value="">-- Select Student --</option>
<?php while($s=mysqli_fetch_assoc($students)){ ?>
<option value="<?= $s['student_id'] ?>">
<?= $s['reg_no']." - ".$s['student_name']." | ".$s['course_code']." | Year ".$s['current_year']." / Sem ".$s['current_semester'] ?>
</option>
<?php } ?>
</select>

<label>Hostel Fee Amount</label>
<input type="number" name="hostel_fee" min="0" required>

<button name="save">Assign Hostel Fee</button>
</form>
</div>

<div class="card">
<h3>📋 Hostel Fee Records</h3>

<table>
<tr>
<th>Register No</th>
<th>Name</th>
<th>Department</th>
<th>Block</th>
<th>Room</th>
<th>Hostel Fee</th>
<th>Status</th>
</tr>
<?php while($r=mysqli_fetch_assoc($list)){ ?>
<tr>
<td><?= $r['register_no'] ?></td>
<td><?= $r['student_name'] ?></td>
<td><?= $r['department'] ?></td>
<td><?= $r['block'] ?></td>
<td><?= $r['room_no'] ?></td>
<td>₹ <?= $r['fee_amount'] ?></td>
<td><?= $r['fee_status'] ?></td>
</tr>
<?php } ?>
</table>
</div>

<a href="/fees_management_system/admin/dashboard.php">
⬅ Back to Dashboard
</a>


</div>

</body>
</html>
