<?php
include "../config/db.php";

if(isset($_POST['save'])){
    $belongs = $_POST['belongs'];
    $name    = $_POST['name'];
    $type    = $_POST['type'];
    $values  = $_POST['values'] ?? '';
    $req     = isset($_POST['required']) ? 1 : 0;

    mysqli_query($conn,"
        INSERT INTO custom_fields
        (belongs_to, field_name, field_type, field_values, is_required)
        VALUES
        ('$belongs','$name','$type','$values',$req)
    ");

    echo "<p class='success'>Custom Field Added</p>";
}
?>

<!DOCTYPE html>
<html>
<head>
<title>Add Custom Field</title>

<style>
body{
    margin:0;
    font-family:Segoe UI, Arial;
    background:#f4f6f9;
}
.container{
    max-width:600px;
    margin:40px auto;
}
.card{
    background:#fff;
    padding:25px;
    border-radius:8px;
    box-shadow:0 2px 8px rgba(0,0,0,0.12);
}
h3{
    margin-top:0;
    color:#2c3e50;
}
form{
    display:grid;
    gap:15px;
}
label{
    font-weight:600;
}
input, select{
    padding:10px;
    border:1px solid #ccc;
    border-radius:5px;
    font-size:14px;
}
input:focus, select:focus{
    outline:none;
    border-color:#1abc9c;
}
.checkbox{
    display:flex;
    align-items:center;
    gap:8px;
}
button{
    padding:12px;
    background:#1abc9c;
    border:none;
    color:#fff;
    font-size:15px;
    border-radius:5px;
    cursor:pointer;
    transition:background 0.3s ease;
}
button:hover{
    background:#16a085;
}
.success{
    color:green;
    font-weight:bold;
    margin-bottom:15px;
}
.note{
    font-size:13px;
    color:#777;
}
.hidden{
    display:none;
}
</style>
</head>

<body>

<div class="container">
<div class="card">

<h3>Add Custom Field</h3>

<form method="POST">

<label>Belongs To</label>
<select name="belongs" required>
    <option value="STUDENT">Student</option>
    <option value="PAYMENT">Payment</option>
    <option value="HOSTEL">Hostel</option>
</select>

<label>Field Name</label>
<input name="name" placeholder="Eg: Aadhaar Number" required>

<label>Field Type</label>
<select name="type" id="fieldType">
    <option value="TEXT">Text</option>
    <option value="NUMBER">Number</option>
    <option value="SELECT">Select</option>
</select>

<div id="valueBox">
    <label>Field Values</label>
    <input name="values" placeholder="Eg: Male,Female,Other">
    <div class="note">Use comma separated values for Select type</div>
</div>

<div class="checkbox">
    <input type="checkbox" name="required" id="req">
    <label for="req">Required Field</label>
</div>

<button name="save">Save Custom Field</button>

</form>

</div>
<a href="dashboard.php" class="back">⬅ Back to Admin Dashboard</a>
</div>

<script>
/* Show values box only for SELECT type */
const typeSelect = document.getElementById("fieldType");
const valueBox = document.getElementById("valueBox");

function toggleValues(){
    if(typeSelect.value === "SELECT"){
        valueBox.classList.remove("hidden");
    }else{
        valueBox.classList.add("hidden");
    }
}

toggleValues();
typeSelect.addEventListener("change", toggleValues);
</script>

</body>
</html>
