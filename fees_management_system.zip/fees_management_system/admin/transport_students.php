<?php
session_start();
if (!isset($_SESSION['role']) || $_SESSION['role'] != 'ADMIN') {
    die("Access Denied");
}

include "../config/db.php";
?>
<!DOCTYPE html>
<html>
<head>
<title>Transport Students Report</title>
<style>
body{font-family:Segoe UI;background:#f4f6f9}
.container{padding:30px}
table{width:100%;border-collapse:collapse;background:#fff}
th,td{border:1px solid #ccc;padding:8px;text-align:center}
th{background:#2c3e50;color:#fff}
h2{color:#2c3e50}
</style>
</head>
<body>

<div class="container">
<h2>🚌 Transport Students Report</h2>

<table>
<tr>
    <th>ID</th>
    <th>Name</th>
    <th>Course</th>
    <th>Year</th>
    <th>Sem</th>
    <th>Phone</th>
</tr>

<?php
$q = mysqli_query($conn,"
    SELECT 
        student_id,
        student_name,
        course_code,
        current_year,
        current_semester,
        phone
    FROM students
    WHERE transport_required = 'Yes'
    ORDER BY course_code, current_year
");

if(!$q){
    die("SQL Error: ".mysqli_error($conn));
}

while($r = mysqli_fetch_assoc($q)){
?>
<tr>
    <td><?= $r['student_id'] ?></td>
    <td><?= htmlspecialchars($r['student_name']) ?></td>
    <td><?= $r['course_code'] ?></td>
    <td><?= $r['current_year'] ?></td>
    <td><?= $r['current_semester'] ?></td>
    <td><?= $r['phone'] ?></td>
</tr>
<?php } ?>

</table>

<br>
<button onclick="window.print()">🖨️ Print / Download</button>

<br><br>
<a href="/fees_management_system/admin/dashboard.php">
⬅ Back to Dashboard
</a>

</div>
</body>
</html>
