<?php
session_start();

if (!isset($_SESSION['role']) || $_SESSION['role'] != 'ADMIN') {
    header("Location: ../auth/login.php");
    exit();
}
include "../config/db.php";

/* ===== DASHBOARD METRICS (STUDENT BASED) ===== */
// Total students
$q = mysqli_query($conn,"SELECT COUNT(*) AS c FROM students");
$total_students = mysqli_fetch_assoc($q)['c'] ?? 0;

// Total collected amount
$q = mysqli_query($conn,"
    SELECT IFNULL(SUM(total_amount),0) AS s 
    FROM payment 
    WHERE status='paid'
");
$total_collected = mysqli_fetch_assoc($q)['s'] ?? 0;

// Total base fee
$q = mysqli_query($conn,"
    SELECT IFNULL(SUM(amount),0) AS t 
    FROM fee_structure_detail
");
$total_fee = mysqli_fetch_assoc($q)['t'] ?? 0;

// Total unpaid fine
$q = mysqli_query($conn,"
    SELECT IFNULL(SUM(fine_amount),0) AS f 
    FROM fine 
    WHERE status='UNPAID'
");
$total_fine = mysqli_fetch_assoc($q)['f'] ?? 0;

// Total concession
$q = mysqli_query($conn,"
    SELECT IFNULL(SUM(concession_amount),0) AS c 
    FROM concession
");
$total_concession = mysqli_fetch_assoc($q)['c'] ?? 0;

// Pending fee
$pending_fees = ($total_fee + $total_fine) - ($total_collected + $total_concession);
if($pending_fees < 0) $pending_fees = 0;

// Defaulters
$q = mysqli_query($conn,"
    SELECT COUNT(*) AS d
    FROM students s
    WHERE NOT EXISTS (
        SELECT 1 FROM payment p 
        WHERE p.student_id = s.student_id 
        AND p.status='paid'
    )
");
$defaulters = mysqli_fetch_assoc($q)['d'] ?? 0;
?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>Admin Dashboard | Fee Management System</title>

<script src="https://cdn.jsdelivr.net/npm/chart.js"></script>

<style>
/* ===== UNIQUE ADMIN THEME ===== */
:root{
    --primary:#1f2933;
    --secondary:#10b981;
    --sidebar:#111827;
    --bg:#f8fafc;
    --card:#ffffff;
    --text:#1f2933;
    --muted:#6b7280;
}

body{margin:0;font-family:"Segoe UI",Arial;background:var(--bg);color:var(--text);}

/* HEADER */
.header{
    background:var(--primary);
    color:#fff;
    padding:14px 25px;
    display:flex;
    align-items:center;
    gap:15px;
}
.header img{height:45px;background:#fff;padding:3px;border-radius:4px;}
.header h1{margin:0;font-size:20px;}
.header p{margin:0;font-size:13px;color:#d1d5db;}

/* LAYOUT */
.container{display:flex;min-height:calc(100vh - 70px);}
.sidebar{
    width:260px;
    background:var(--sidebar);
    padding-top:15px;
}
.sidebar a{
    display:block;
    padding:12px 20px;
    color:#d1d5db;
    text-decoration:none;
    transition:.3s;
}
.sidebar a:hover{
    background:var(--secondary);
    color:#fff;
    padding-left:28px;
}
.logout{color:#f87171 !important;}

.content{flex:1;padding:30px;}
h2{margin-top:0;color:var(--primary);}

/* STATS */
.stats{
    display:grid;
    grid-template-columns:repeat(auto-fit,minmax(220px,1fr));
    gap:20px;
    margin-bottom:30px;
}
.stat{
    background:var(--card);
    padding:22px;
    border-radius:14px;
    box-shadow:0 6px 18px rgba(0,0,0,0.08);
    border-left:6px solid var(--secondary);
}
.stat h3{margin:0;font-size:14px;color:var(--muted);}
.stat h1{margin:10px 0 0;font-size:28px;color:var(--primary);}

/* CHARTS */
.charts{
    display:grid;
    grid-template-columns:2fr 1fr;
    gap:20px;
}
.chart-box{
    background:var(--card);
    padding:20px;
    border-radius:14px;
    box-shadow:0 6px 18px rgba(0,0,0,0.08);
}
</style>
</head>

<body>

<div class="header">
    <img src="../assets/images/college_logo.png">
    <div>
        <h1>Nanjiah Lingammal Polytechnic College</h1>
        <p>Fee Management System – Admin Panel</p>
    </div>
</div>

<div class="container">

<div class="sidebar">
    <a href="dashboard.php"> Dashboard</a>
    <a href="students.php"> Manage Students</a>
    <a href="fee_structure.php"> Fee Structure</a>
    <a href="concession.php"> Concession</a>
    <a href="fine.php"> Fine</a>
    <a href="transport_fee_assign.php"> Transport Fee </a>
    <a href="hostel_fee_assign.php"> Hostel Fee</a> 
    <a href="transport_students.php"> Transport Students</a>
    <a href="hostel_students.php"> Hostel Students</a>
    <a href="hostel_fee_report.php"> Hostel Fee Report</a>
     <a href="transport_fee_report.php"> Transport Fee Report</a>
     <a href="payments.php"> Payments Record</a>
    <a href="report_student_fee.php"> Student Report Fee</a>
    <a href="report_history.php"> Report History</a>
    <a href="report_daily.php"> Report Daily</a>
    <a href="report_pending.php"> Pending Fees</a>
    <a href="../auth/logout.php" class="logout"> Logout</a>
</div>

<div class="content">
<h2>Admin Dashboard</h2>

<div class="stats">
    <div class="stat">
        <h3>Total Students</h3>
        <h1><?= $total_students ?></h1>
    </div>
    <div class="stat">
        <h3>Total Collected</h3>
        <h1>₹<?= number_format($total_collected,2) ?></h1>
    </div>
    <div class="stat">
        <h3>Pending Fees</h3>
        <h1>₹<?= number_format($pending_fees,2) ?></h1>
    </div>
    <div class="stat">
        <h3>Defaulters</h3>
        <h1><?= $defaulters ?></h1>
    </div>
</div>

<div class="charts">
    <div class="chart-box">
        <h3>Fee Overview</h3>
        <canvas id="barChart"></canvas>
    </div>
    <div class="chart-box">
        <h3>Fee Distribution</h3>
        <canvas id="pieChart"></canvas>
    </div>
</div>

</div>
</div>

<script>
new Chart(document.getElementById('barChart'),{
    type:'bar',
    data:{
        labels:['Collected','Pending','Defaulters'],
        datasets:[{
            data:[<?= $total_collected ?>,<?= $pending_fees ?>,<?= $defaulters ?>],
            backgroundColor:['#10b981','#f59e0b','#ef4444']
        }]
    },
    options:{plugins:{legend:{display:false}}}
});

new Chart(document.getElementById('pieChart'),{
    type:'doughnut',
    data:{
        labels:['Collected','Pending'],
        datasets:[{
            data:[<?= $total_collected ?>,<?= $pending_fees ?>],
            backgroundColor:['#10b981','#f59e0b']
        }]
    }
});
</script>

</body>
</html>