<?php
session_start();
if (!isset($_SESSION['role']) || $_SESSION['role'] != 'ADMIN') die("Access Denied");
include "../config/db.php";

/* ===============================
   ACTIVE ROW STATE
================================ */
$active_student_id = $_POST['student_id'] ?? '';
$active_stage      = $_POST['stage'] ?? '';

/* ===============================
   COUNTS
================================ */

// total transport-required students
$total_students = mysqli_fetch_assoc(mysqli_query($conn,"
    SELECT COUNT(*) AS total
    FROM students
    WHERE transport_required='Yes'
"))['total'] ?? 0;

// assigned transport students (only transport-required)
$assigned_count = mysqli_fetch_assoc(mysqli_query($conn,"
    SELECT COUNT(DISTINCT f.student_id) AS total
    FROM transport_fee_assign f
    JOIN students s ON s.student_id = f.student_id
    WHERE s.transport_required='Yes'
"))['total'] ?? 0;

// pending
$pending_count = max(0, $total_students - $assigned_count);

/* ===============================
   FETCH PENDING STUDENTS
================================ */
$students = mysqli_query($conn,"
    SELECT s.student_id, s.student_name, s.reg_no
    FROM students s
    WHERE s.transport_required='Yes'
    AND NOT EXISTS (
        SELECT 1 FROM transport_fee_assign f
        WHERE f.student_id = s.student_id
    )
    ORDER BY s.student_name
");

/* ===============================
   FETCH STAGES
================================ */
$stages = mysqli_query($conn,"
    SELECT DISTINCT start_point
    FROM transport
    WHERE status='Active'
");

/* ===============================
   FETCH ROUTES (PER ACTIVE ROW)
================================ */
$filteredRoutes = [];
if ($active_student_id && $active_stage) {
    $sid   = mysqli_real_escape_string($conn, $active_student_id);
    $stage = mysqli_real_escape_string($conn, $active_stage);

    $q = mysqli_query($conn,"
        SELECT transport_id, route_name
        FROM transport
        WHERE start_point='$stage'
        AND status='Active'
    ");

    while ($r = mysqli_fetch_assoc($q)) {
        $filteredRoutes[] = $r;
    }
}

/* ===============================
   SAVE TRANSPORT FEE
================================ */
if (isset($_POST['assign'])) {

    $student_id   = mysqli_real_escape_string($conn, $_POST['student_id']);
    $transport_id = mysqli_real_escape_string($conn, $_POST['transport_id']);
    $fee          = (float)$_POST['fee'];

    $check = mysqli_query($conn,"
        SELECT 1 FROM transport_fee_assign
        WHERE student_id='$student_id'
    ");

    if (mysqli_num_rows($check) == 0) {

        mysqli_query($conn,"
            INSERT INTO transport_fee_assign
            (student_id, transport_id, transport_fee, status)
            VALUES
            ('$student_id','$transport_id','$fee','Pending')
        ");

        header("Location: transport_fee_assign.php?success=1");
        exit();
    } else {
        header("Location: transport_fee_assign.php?exists=1");
        exit();
    }
}

/* ===============================
   FETCH ASSIGNED STUDENTS
================================ */
$assigned_students = mysqli_query($conn,"
    SELECT 
        s.reg_no,
        s.student_name,
        t.start_point,
        t.route_name,
        f.transport_fee,
        f.status
    FROM transport_fee_assign f
    JOIN students s ON s.student_id = f.student_id
    JOIN transport t ON t.transport_id = f.transport_id
    ORDER BY s.student_name
");
?>
<!DOCTYPE html>
<html>
<head>
<title>Transport Fee Assignment</title>
<style>
body{font-family:Arial;background:#f4f6f9;}
.container{max-width:1200px;margin:40px auto;}
.card{background:#fff;padding:25px;border-radius:8px;margin-bottom:30px;}
.summary{display:flex;gap:20px;margin-bottom:20px;}
.summary div{flex:1;padding:15px;border-radius:8px;text-align:center;}
table{width:100%;border-collapse:collapse;}
th{background:#2c3e50;color:#fff;padding:10px;}
td{padding:8px;border:1px solid #ddd;text-align:center;}
select,input{padding:6px;}
button{padding:6px 12px;background:#2980b9;color:#fff;border:none;cursor:pointer;}
.success{background:#e8f7ee;color:#1e8449;padding:10px;margin-bottom:15px;}
.error{background:#fdecea;color:#c0392b;padding:10px;margin-bottom:15px;}
</style>
</head>
<body>

<div class="container">

<div class="card">
<h3>🚌 Transport Fee Assignment</h3>

<?php
if(isset($_GET['success'])) echo "<div class='success'>✅ Transport fee assigned successfully</div>";
if(isset($_GET['exists']))  echo "<div class='error'>⚠️ Already assigned</div>";
?>

<div class="summary">
    <div style="background:#ecf0f1;">
        <h4>Transport Required</h4>
        <h2><?= $total_students ?></h2>
    </div>
    <div style="background:#d5f5e3;">
        <h4>Assigned</h4>
        <h2><?= $assigned_count ?></h2>
    </div>
    <div style="background:#fdebd0;">
        <h4>Pending</h4>
        <h2><?= $pending_count ?></h2>
    </div>
</div>

<h4>🕒 Pending Transport Fee Assignment</h4>

<table>
<tr>
    <th>Register No</th>
    <th>Student Name</th>
    <th>Stage</th>
    <th>Route</th>
    <th>Fee (₹)</th>
    <th>Action</th>
</tr>

<?php while($s=mysqli_fetch_assoc($students)){ ?>
<tr>
<form method="post">
<td><?= $s['reg_no'] ?></td>
<td><?= $s['student_name'] ?></td>

<td>
<select name="stage" onchange="this.form.submit()" required>
<option value="">Select Stage</option>
<?php mysqli_data_seek($stages,0);
while($st=mysqli_fetch_assoc($stages)){ ?>
<option value="<?= $st['start_point'] ?>"
<?= ($active_student_id==$s['student_id'] && $active_stage==$st['start_point'])?'selected':'' ?>>
<?= $st['start_point'] ?>
</option>
<?php } ?>
</select>
</td>

<td>
<select name="transport_id" required>
<option value="">Select Route</option>
<?php
if($active_student_id==$s['student_id']){
foreach($filteredRoutes as $r){ ?>
<option value="<?= $r['transport_id'] ?>">
<?= $r['route_name'] ?>
</option>
<?php }} ?>
</select>
</td>

<td><input type="number" name="fee" required></td>

<td>
<input type="hidden" name="student_id" value="<?= $s['student_id'] ?>">
<button name="assign">Assign</button>
</td>
</form>
</tr>
<?php } ?>
</table>
</div>

<div class="card">
<h3>📋 Students With Transport Fee Assigned</h3>
<table>
<tr>
<th>Register No</th>
<th>Name</th>
<th>Stage</th>
<th>Route</th>
<th>Fee</th>
<th>Status</th>
</tr>

<?php if(mysqli_num_rows($assigned_students)){
while($a=mysqli_fetch_assoc($assigned_students)){ ?>
<tr>
<td><?= $a['reg_no'] ?></td>
<td><?= $a['student_name'] ?></td>
<td><?= $a['start_point'] ?></td>
<td><?= $a['route_name'] ?></td>
<td><?= $a['transport_fee'] ?></td>
<td><?= $a['status'] ?></td>
</tr>
<?php }} else { ?>
<tr><td colspan="6">No students assigned</td></tr>
<?php } ?>
</table>
</div>

<a href="/fees_management_system/admin/dashboard.php">
⬅ Back to Dashboard
</a>
</div>
</body>
</html>
