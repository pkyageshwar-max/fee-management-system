<?php
session_start();
if($_SESSION['role']!='ADMIN') die("Access Denied");
include "../config/db.php";

$q = mysqli_query($conn, "
SELECT
 s.reg_no,
 s.student_name,
 s.course_code,
 s.current_year,
 s.current_semester,

 SUM(fs.amount) AS academic_fee,
 IFNULL(SUM(c.concession_amount),0) AS concession,
 IFNULL(SUM(f.fine_amount),0) AS fine,
 IFNULL(SUM(p.total_amount),0) AS paid

FROM students s
LEFT JOIN fee_structure_detail fs
 ON fs.course=s.course_code
AND fs.academic_year=s.current_year
AND fs.semester=s.current_semester

LEFT JOIN concession c ON c.student_id=s.student_id
LEFT JOIN fine f ON f.student_id=s.student_id AND f.status='UNPAID'
LEFT JOIN payment p ON p.student_id=s.student_id AND p.status='SUCCESS'

GROUP BY s.student_id
ORDER BY s.reg_no
");
?>
<!DOCTYPE html>
<html>
<head>
<title>Student Fee Report</title>
<style>
body{font-family:Segoe UI;background:#f4f6f9;margin:0}
.container{padding:20px}
h2{text-align:center}
table{width:100%;border-collapse:collapse;font-size:13px}
th,td{border:1px solid #000;padding:6px;text-align:center}
th{background:#eee}
.print-btn{margin-bottom:15px}
@media print{
.print-btn{display:none}
body{background:#fff}
}
</style>
</head>
<body>

<div class="container">

<button class="print-btn" onclick="window.print()">🖨️ Print Report</button>

<h2>Nanjiah Lingammal Polytechnic College<br>
Student Fee Ledger</h2>

<table>
<tr>
<th>Reg No</th>
<th>Name</th>
<th>Course</th>
<th>Year</th>
<th>Sem</th>
<th>Total Fee</th>
<th>Concession</th>
<th>Fine</th>
<th>Paid</th>
<th>Pending</th>
<th>Status</th>
</tr>

<?php while($r=mysqli_fetch_assoc($q)){
$total = $r['academic_fee'];
$payable = $total - $r['concession'] + $r['fine'];
$pending = $payable - $r['paid'];
$status = ($pending<=0) ? "PAID" : "PENDING";
?>
<tr>
<td><?= $r['reg_no'] ?></td>
<td><?= $r['student_name'] ?></td>
<td><?= $r['course_code'] ?></td>
<td><?= $r['current_year'] ?></td>
<td><?= $r['current_semester'] ?></td>
<td>₹<?= number_format($total,2) ?></td>
<td>-₹<?= number_format($r['concession'],2) ?></td>
<td>+₹<?= number_format($r['fine'],2) ?></td>
<td>₹<?= number_format($r['paid'],2) ?></td>
<td><b>₹<?= number_format($pending,2) ?></b></td>
<td><b><?= $status ?></b></td>
</tr>
<?php } ?>

</table>
<a href="/fees_management_system/admin/dashboard.php">
⬅ Back to Dashboard
</a>

</div>
</body>
</html>