<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);

include "../config/db.php";

/* ---------------- Filters ---------------- */
$course = $_GET['course'] ?? '';
$year   = $_GET['year'] ?? '';
$sem    = $_GET['sem'] ?? '';

$where = "WHERE 1=1";

if($course != ''){
    $where .= " AND s.course_code = '".mysqli_real_escape_string($conn,$course)."'";
}
if($year != ''){
    $where .= " AND s.current_year = ".(int)$year;
}
if($sem != ''){
    $where .= " AND s.current_semester = ".(int)$sem;
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>Pending Fee Report | Admin</title>

<style>
body{margin:0;font-family:"Segoe UI",Arial,sans-serif;background:#f4f6f9;}
.container{padding:30px;}
h2{color:#c0392b;}
.card{background:#fff;padding:20px;border-radius:8px;box-shadow:0 2px 6px rgba(0,0,0,0.1);}
table{width:100%;border-collapse:collapse;font-size:13px;}
th{background:#c0392b;color:#fff;padding:8px;}
td{padding:8px;border:1px solid #ddd;text-align:center;}
.back{display:inline-block;margin-top:20px;text-decoration:none;color:#c0392b;font-weight:bold;}
</style>
</head>

<body>

<div class="container">
<h2>Pending Fee Report</h2>

<div class="card">
<table>
<tr>
<th>Student</th>
<th>Course</th>
<th>Year</th>
<th>Sem</th>
<th>Tuition</th>
<th>Exam</th>
<th>Bus</th>
<th>Book</th>
<th>Maintenance</th>
<th>Total</th>
<th>Concession</th>
<th>Fine</th>
<th>Payable</th>
<th>Paid</th>
<th>Pending</th>
</tr>

<?php
$q = mysqli_query($conn, "

SELECT 
 s.student_id,
 s.student_name,
 s.course_code,
 s.current_year,
 s.current_semester,

 SUM(CASE WHEN fh.head_name LIKE '%Tuition%' THEN fs.amount ELSE 0 END) AS tuition_fee,
 SUM(CASE WHEN fh.head_name LIKE '%Exam%' THEN fs.amount ELSE 0 END) AS exam_fee,
 SUM(CASE WHEN fh.head_name LIKE '%Bus%' THEN fs.amount ELSE 0 END) AS bus_fee,
 SUM(CASE WHEN fh.head_name LIKE '%Book%' THEN fs.amount ELSE 0 END) AS book_fee,
 SUM(CASE WHEN fh.head_name LIKE '%Maintenance%' THEN fs.amount ELSE 0 END) AS maintenance_fee,

 IFNULL(SUM(fs.amount),0) AS total_fee,
 IFNULL(SUM(c.concession_amount),0) AS concession,
 IFNULL(SUM(f.fine_amount),0) AS fine,
 IFNULL(SUM(p.total_amount),0) AS paid_amount

FROM students s

LEFT JOIN fee_structure_detail fs
 ON fs.course = s.course_code
AND fs.academic_year = s.current_year
AND fs.semester = s.current_semester

LEFT JOIN fee_head fh ON fh.head_id = fs.head_id
LEFT JOIN concession c ON c.student_id = s.student_id
LEFT JOIN fine f ON f.student_id = s.student_id AND f.status='UNPAID'
LEFT JOIN payment p ON p.student_id = s.student_id AND p.status='SUCCESS'

$where

GROUP BY s.student_id

HAVING (total_fee - concession + fine - paid_amount) > 0

ORDER BY s.student_name
");

if(!$q){
    die("SQL Error: ".mysqli_error($conn));
}

while($r = mysqli_fetch_assoc($q)){

$total_fee = $r['total_fee'];
$payable   = $total_fee - $r['concession'] + $r['fine'];
$pending   = $payable - $r['paid_amount'];
?>

<tr>
<td><?= htmlspecialchars($r['student_name']) ?></td>
<td><?= htmlspecialchars($r['course_code']) ?></td>
<td><?= $r['current_year'] ?></td>
<td><?= $r['current_semester'] ?></td>

<td>₹<?= number_format($r['tuition_fee'],2) ?></td>
<td>₹<?= number_format($r['exam_fee'],2) ?></td>
<td>₹<?= number_format($r['bus_fee'],2) ?></td>
<td>₹<?= number_format($r['book_fee'],2) ?></td>
<td>₹<?= number_format($r['maintenance_fee'],2) ?></td>

<td><b>₹<?= number_format($total_fee,2) ?></b></td>
<td>-₹<?= number_format($r['concession'],2) ?></td>
<td>+₹<?= number_format($r['fine'],2) ?></td>
<td><b>₹<?= number_format($payable,2) ?></b></td>
<td>₹<?= number_format($r['paid_amount'],2) ?></td>
<td><b style="color:red">₹<?= number_format($pending,2) ?></b></td>
</tr>

<?php } ?>
</table>
</div>

<a href="/fees_management_system/admin/dashboard.php">
⬅ Back to Dashboard
</a>

</div>

</body>
</html>
