<?php
session_start();
if($_SESSION['role']!='ADMIN') die("Access Denied");
include "../config/db.php";

$msg = "";

/* =========================
   CSV IMPORT (ONLY CSV)
   ========================= */
if(isset($_POST['import'])){

    if(isset($_FILES['file']) && $_FILES['file']['name'] != ""){

        $filename = $_FILES['file']['name'];
        $ext = strtolower(pathinfo($filename, PATHINFO_EXTENSION));

        if($ext != "csv"){
            $msg = "❌ Only CSV files are allowed!";
        } else {

            $file = fopen($_FILES['file']['tmp_name'], "r");
            fgetcsv($file); // skip header

            $inserted = 0;
            $skipped  = 0;

            while(($data = fgetcsv($file, 10000, ",")) !== FALSE){

                // ✅ Now expecting 23 columns (including hostel_required)
                if(count($data) < 23){
                    $skipped++;
                    continue;
                }

                $student_id = mysqli_real_escape_string($conn, trim($data[0]));

                // ✅ Skip duplicate student
                $check = mysqli_query($conn,"
                    SELECT student_id FROM students WHERE student_id='$student_id'
                ");
                if(mysqli_num_rows($check) > 0){
                    $skipped++;
                    continue;
                }

                // ---------- INSERT STUDENT ----------
                $insertStudent = mysqli_query($conn,"
                INSERT INTO students
                (student_id, student_name, dob, mother_tongue, gender, religion, community, caste,
                 aadhar_no, umis_no, emis_no, blood_group, phone, email, address, student_photo,
                 course_code, date_of_joining, batch_year, reg_no, current_year, current_semester, hostel_required)
                VALUES
                (
                 '$data[0]','$data[1]','$data[2]','$data[3]','$data[4]','$data[5]','$data[6]','$data[7]',
                 '$data[8]','$data[9]','$data[10]','$data[11]','$data[12]','$data[13]','$data[14]','$data[15]',
                 '$data[16]','$data[17]','$data[18]','$data[19]','$data[20]','$data[21]','$data[22]'
                )
                ");

                // ---------- AUTO CREATE STUDENT SESSION ----------
                if($insertStudent){

                    $academic_year = date("Y");
                    $semester      = (int)$data[21];

                    mysqli_query($conn,"
                    INSERT INTO student_session (student_id, academic_year, semester)
                    VALUES ('$student_id', $academic_year, $semester)
                    ");

                    $inserted++;
                }
            }

            fclose($file);

            $msg = "✅ Import completed | Inserted: $inserted | Skipped: $skipped";
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>Student Management | Admin</title>

<style>
body{margin:0;font-family:"Segoe UI",Arial;background:#f4f6f9;}
.container{padding:30px;}
h2,h3{color:#2c3e50;}
.card{
    background:#fff;padding:20px;border-radius:8px;
    box-shadow:0 2px 6px rgba(0,0,0,0.1);margin-bottom:25px;
}
button{
    padding:10px 20px;background:#3498db;border:none;
    color:#fff;border-radius:5px;cursor:pointer;
}
button:hover{background:#2980b9;}
.msg{margin-bottom:15px;font-weight:bold;color:#2c7a2c;}
table{width:100%;border-collapse:collapse;background:#fff;font-size:13px;}
table th{background:#2c3e50;color:#fff;padding:8px;}
table td{padding:8px;border:1px solid #ddd;text-align:center;}
.back{
    display:inline-block;margin-top:20px;
    text-decoration:none;color:#3498db;font-weight:bold;
}
</style>
</head>

<body>

<div class="container">

<h2>Student Management</h2>

<div class="card">
<h3>Import Students (CSV Only)</h3>

<?php if($msg!=""){ echo "<p class='msg'>$msg</p>"; } ?>

<form method="POST" enctype="multipart/form-data">
    <input type="file" name="file" accept=".csv" required>
    <br><br>
    <button type="submit" name="import">Import CSV</button>
</form>
</div>

<div class="card">
<h3>All Students</h3>

<table>
<tr>
<th>ID</th>
<th>Name</th>
<th>DOB</th>
<th>Gender</th>
<th>Phone</th>
<th>Email</th>
<th>Course</th>
<th>Batch</th>
<th>Reg No</th>
<th>Year</th>
<th>Sem</th>
<th>Hostel</th>
<th>Transport</th>

</tr>

<?php
$q = mysqli_query($conn,"
    SELECT 
        s.*,
        CASE 
            WHEN t.student_id IS NULL THEN 'No'
            ELSE 'Yes'
        END AS transport_status
    FROM students s
    LEFT JOIN transport_fee_assign t
        ON s.student_id = t.student_id
    ORDER BY s.created_at DESC
");

while($r = mysqli_fetch_assoc($q)){
?>
<tr>
<td><?= $r['student_id'] ?></td>
<td><?= htmlspecialchars($r['student_name']) ?></td>
<td><?= $r['dob'] ?></td>
<td><?= $r['gender'] ?></td>
<td><?= $r['phone'] ?></td>
<td><?= $r['email'] ?></td>
<td><?= $r['course_code'] ?></td>
<td><?= $r['batch_year'] ?></td>
<td><?= $r['reg_no'] ?></td>
<td><?= $r['current_year'] ?></td>
<td><?= $r['current_semester'] ?></td>
<td>
    <?php if($r['hostel_required']=='Yes'){ ?>
        <span style="color:green;font-weight:bold;">Yes</span>
    <?php } else { ?>
        <span style="color:red;">No</span>
    <?php } ?>
</td>

<td>
<?php if($r['transport_required']=='Yes'){ ?>
    <span style='color:green;font-weight:bold;'>Yes</span>
<?php } else { ?>
    <span style='color:red;'>No</span>
<?php } ?>
</td>


</tr>
<?php } ?>
</table>

</div>

<a href="/fees_management_system/admin/dashboard.php">
⬅ Back to Dashboard
</a>


</div>

</body>
</html>