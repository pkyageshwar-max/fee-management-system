<?php
session_start();

if (!isset($_SESSION['role']) || $_SESSION['role'] !== 'ADMIN') {
    die("Access Denied");
}

include "../config/db.php";
?>

<!DOCTYPE html>
<html>
<head>
<title>Transport Fee Collection Report</title>

<style>
body{
    font-family:Segoe UI;
    background:#f4f6f9;
}

.container{
    padding:30px;
}

table{
    width:100%;
    border-collapse:collapse;
    background:#fff;
}

th,td{
    border:1px solid #ccc;
    padding:8px;
    text-align:center;
}

th{
    background:#2c3e50;
    color:#fff;
}

h2{
    color:#2c3e50;
}

.total{
    font-weight:bold;
    background:#ecf0f1;
}

button{
    padding:10px 15px;
    border:none;
    background:#3498db;
    color:#fff;
    cursor:pointer;
    border-radius:5px;
}

a{
    text-decoration:none;
    font-weight:bold;
}
</style>

</head>

<body>

<div class="container">

<h2>🚌 Transport Fee Collection Report</h2>

<table>

<tr>
<th>Date</th>
<th>Student ID</th>
<th>Name</th>
<th>Receipt No</th>
<th>Amount</th>
</tr>

<?php

$total = 0;

$q = mysqli_query($conn,"
SELECT
p.payment_date,
p.receipt_no,
p.transport_paid,
s.student_id,
s.student_name

FROM payment p

JOIN students s
ON p.student_id = s.student_id

WHERE p.transport_paid > 0

AND p.status IN ('SUCCESS','Paid')

ORDER BY p.payment_date DESC
");

while($r = mysqli_fetch_assoc($q)){

$total += $r['transport_paid'];

?>

<tr>

<td><?= $r['payment_date'] ?></td>

<td><?= $r['student_id'] ?></td>

<td><?= $r['student_name'] ?></td>

<td><?= $r['receipt_no'] ?></td>

<td>₹<?= number_format($r['transport_paid'],2) ?></td>

</tr>

<?php } ?>

<tr class="total">

<td colspan="4">Total Transport Fee Collected</td>

<td>₹<?= number_format($total,2) ?></td>

</tr>

</table>

<br>

<button onclick="window.print()">
🖨️ Print / Download
</button>

<br><br>

<a href="/fees_management_system/admin/dashboard.php">
⬅ Back to Dashboard
</a>

</div>

</body>
</html>