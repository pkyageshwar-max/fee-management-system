<?php
include "../config/db.php";

/* ---------- Date filter ---------- */
$date = $_GET['date'] ?? date('Y-m-d');
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>Daily Fee Collection Report | Admin</title>

<style>
body{
    margin:0;
    font-family:"Segoe UI", Arial, sans-serif;
    background:#f4f6f9;
}
.container{
    padding:30px;
}
h2{ color:#2c3e50; }
.card{
    background:#fff;
    padding:20px;
    border-radius:8px;
    box-shadow:0 2px 6px rgba(0,0,0,0.1);
    margin-bottom:20px;
}
.filter-form{
    display:flex;
    gap:15px;
    align-items:center;
}
.filter-form input{
    padding:8px 10px;
    border:1px solid #ccc;
    border-radius:5px;
}
.filter-form button{
    padding:8px 15px;
    background:#3498db;
    border:none;
    color:#fff;
    border-radius:5px;
    cursor:pointer;
}
.filter-form button:hover{ background:#2980b9; }

table{
    width:100%;
    border-collapse:collapse;
}
table th{
    background:#2c3e50;
    color:#fff;
    padding:10px;
}
table td{
    padding:10px;
    border:1px solid #ddd;
    text-align:center;
}
.total-row{
    background:#ecf0f1;
    font-weight:bold;
}
.back{
    display:inline-block;
    margin-top:20px;
    text-decoration:none;
    color:#3498db;
    font-weight:bold;
}
</style>
</head>

<body>

<div class="container">

<h2>Daily Fee Collection Report</h2>

<div class="card">
<form method="GET" class="filter-form">
    <label><b>Select Date:</b></label>
    <input type="date" name="date" value="<?= $date ?>">
    <button type="submit">View Report</button>
</form>
</div>

<div class="card">

<table>
<tr>
    <th>Student Name</th>
    <th>Course</th>
    <th>Year</th>
    <th>Semester</th>
    <th>Amount Paid</th>
    <th>Mode</th>
    <th>Receipt No</th>
    <th>Transaction ID</th>
    <th>Date</th>
</tr>

<?php
$q = mysqli_query($conn,"
SELECT 
    s.student_name,
    s.course_code,
    s.current_year,
    s.current_semester,
    p.total_amount,
    p.payment_mode,
    p.receipt_no,
    p.transaction_id,
    p.payment_date
FROM payment p
JOIN students s ON p.student_id = s.student_id
WHERE p.status='SUCCESS'
AND DATE(p.payment_date) = '$date'
ORDER BY p.payment_date DESC
");

$total = 0;

if(mysqli_num_rows($q)==0){
    echo "<tr><td colspan='9'>No payments found</td></tr>";
}

while($r = mysqli_fetch_assoc($q)){
    $total += $r['total_amount'];
?>
<tr>
    <td><?= htmlspecialchars($r['student_name']) ?></td>
    <td><?= htmlspecialchars($r['course_code']) ?></td>
    <td><?= $r['current_year'] ?></td>
    <td><?= $r['current_semester'] ?></td>
    <td>₹<?= number_format($r['total_amount'],2) ?></td>
    <td><?= htmlspecialchars($r['payment_mode']) ?></td>
    <td><?= htmlspecialchars($r['receipt_no']) ?></td>
    <td><?= htmlspecialchars($r['transaction_id']) ?></td>
    <td><?= $r['payment_date'] ?></td>
</tr>
<?php } ?>

<tr class="total-row">
    <td colspan="4">TOTAL COLLECTION</td>
    <td colspan="5">₹<?= number_format($total,2) ?></td>
</tr>

</table>
</div>
<a href="/fees_management_system/admin/dashboard.php">
⬅ Back to Dashboard
</a>


</div>

</body>
</html>
