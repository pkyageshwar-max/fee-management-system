<?php
session_start();

/* ===============================
   ADMIN SESSION SECURITY
================================ */
if(!isset($_SESSION['role']) || $_SESSION['role']!='ADMIN'){
die("Access Denied");
}

include "../config/db.php";

$msg="";
$error="";


/* ===============================
   FETCH FEE HEADS
================================ */
$heads=mysqli_query($conn,"
SELECT head_id,fee_code,head_name,default_amount
FROM fee_head
WHERE fee_code NOT LIKE 'H%'
ORDER BY fee_code
");


/* ===============================
   COUNT DEPARTMENTS
================================ */
$countDept=mysqli_query($conn,"
SELECT COUNT(DISTINCT course) AS total_dept
FROM fee_structure_detail
");

$deptData=mysqli_fetch_assoc($countDept);
$totalDept=$deptData['total_dept'] ?? 0;


/* ===============================
   LIST DEFINED FEE STRUCTURES
================================ */
$defined=mysqli_query($conn,"
SELECT course,academic_year,semester,
COUNT(head_id) AS total_heads
FROM fee_structure_detail
GROUP BY course,academic_year,semester
ORDER BY course,academic_year,semester
");


/* ===============================
   SAVE FEE STRUCTURE
================================ */
if(isset($_POST['save'])){

$course=mysqli_real_escape_string($conn,$_POST['course']);
$year=(int)$_POST['year'];
$sem=(int)$_POST['sem'];

$inserted=0;
$skipped=0;

foreach($_POST['amount'] as $head_id=>$amt){

$amt=(float)$amt;
$head_id=(int)$head_id;

if($amt>0){

$check=mysqli_query($conn,"
SELECT head_id
FROM fee_structure_detail
WHERE course='$course'
AND academic_year=$year
AND semester=$sem
AND head_id=$head_id
");

if(mysqli_num_rows($check)==0){

mysqli_query($conn,"
INSERT INTO fee_structure_detail
(course,academic_year,semester,head_id,amount)
VALUES
('$course',$year,$sem,$head_id,$amt)
");

$inserted++;

}else{

$skipped++;

}

}

}

if($inserted>0 && $skipped==0){

$msg="✅ Fee structure saved successfully.";

}
elseif($inserted>0 && $skipped>0){

$msg="⚠️ Fee structure saved. Some heads already existed.";

}
else{

$error="❌ Fee structure already exists.";

}

}
?>

<!DOCTYPE html>
<html>
<head>
<title>Fee Structure Management</title>

<style>

body{
margin:0;
font-family:"Segoe UI",Arial;
background:#f4f6f9;
}

.container{
max-width:950px;
margin:40px auto;
background:#fff;
padding:30px;
border-radius:10px;
box-shadow:0 4px 12px rgba(0,0,0,0.08);
}

h2{text-align:center;margin-bottom:15px;}

.stats{
background:#f1f5ff;
border-left:6px solid #4e73df;
padding:12px;
border-radius:6px;
margin-bottom:15px;
font-weight:600;
}

table{
width:100%;
border-collapse:collapse;
margin-bottom:25px;
}

table th{
background:#4e73df;
color:white;
padding:10px;
}

table td{
padding:9px;
border:1px solid #ddd;
text-align:center;
}

.row{
display:grid;
grid-template-columns:1fr 1fr 1fr;
gap:15px;
margin-bottom:20px;
}

.fee-row{
display:grid;
grid-template-columns:2fr 1fr;
gap:15px;
margin-bottom:12px;
}

input,select{
width:100%;
padding:10px;
border:1px solid #ccc;
border-radius:6px;
}

button{
background:#28a745;
color:white;
border:none;
padding:12px 22px;
border-radius:6px;
cursor:pointer;
}

.msg{
background:#e9ffe9;
color:#137333;
padding:10px;
margin-bottom:15px;
border-radius:6px;
}

.err{
background:#ffeaea;
color:#c0392b;
padding:10px;
margin-bottom:15px;
border-radius:6px;
}

.back{
margin-top:20px;
display:inline-block;
color:#007bff;
text-decoration:none;
font-weight:600;
}

</style>

</head>

<body>

<div class="container">

<h2>Fee Structure Management</h2>

<div class="stats">
📊 Total Departments with Fee Structure : <?= $totalDept ?>
</div>

<h3>📋 Already Defined Fee Structures</h3>

<table>

<tr>
<th>Department</th>
<th>Academic Year</th>
<th>Semester</th>
</tr>

<?php
if(mysqli_num_rows($defined)>0){

while($d=mysqli_fetch_assoc($defined)){
?>

<tr>
<td><?= htmlspecialchars($d['course']) ?></td>
<td><?= $d['academic_year'] ?></td>
<td><?= $d['semester'] ?></td>
</tr>

<?php }} else{ ?>

<tr>
<td colspan="3" style="color:red;">No Fee Structure Defined</td>
</tr>

<?php } ?>

</table>


<?php if($msg!=""){ ?>
<div class="msg"><?= $msg ?></div>
<?php } ?>

<?php if($error!=""){ ?>
<div class="err"><?= $error ?></div>
<?php } ?>


<form method="post">

<div class="row">

<div>

<label>Course / Department</label>

<select name="course" required>

<?php
$c=mysqli_query($conn,"
SELECT DISTINCT course_code
FROM students
ORDER BY course_code
");

while($r=mysqli_fetch_assoc($c)){
echo "<option value='{$r['course_code']}'>{$r['course_code']}</option>";
}
?>

</select>

</div>

<div>

<label>Academic Year</label>
<input type="number" name="year" required>

</div>

<div>

<label>Semester</label>
<input type="number" name="sem" required>

</div>

</div>

<h3>Fee Components</h3>

<?php while($h=mysqli_fetch_assoc($heads)){ ?>

<div class="fee-row">

<div>
<b><?= $h['fee_code']." - ".$h['head_name'] ?></b>
</div>

<div>

<input type="number"
name="amount[<?= $h['head_id']?>]"
value="<?= $h['default_amount']?>"
min="0">

</div>

</div>

<?php } ?>

<br>

<button type="submit" name="save">
Save Fee Structure
</button>

</form>


<a class="back" href="dashboard.php">
⬅ Back to Dashboard
</a>

</div>

</body>
</html>