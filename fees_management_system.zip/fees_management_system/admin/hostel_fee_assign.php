<?php
session_start();

/* ===============================
   AUTH CHECK
================================ */
if (!isset($_SESSION['role']) || $_SESSION['role'] !== 'ADMIN') {
    header("Location: ../auth/login.php");
    exit();
}

/* ===============================
   DB CONNECTION  ✅ FIXED
================================ */
include "../config/db.php";

if (!isset($conn)) {
    die("Database connection failed");
}

/* ===============================
   COUNTS
================================ */
$total_required = mysqli_fetch_assoc(mysqli_query($conn,"
    SELECT COUNT(*) AS total
    FROM students
    WHERE hostel_required='Yes'
"))['total'] ?? 0;

$assigned_count = mysqli_fetch_assoc(mysqli_query($conn,"
    SELECT COUNT(DISTINCT student_id) AS total
    FROM hostel_fee_assign
"))['total'] ?? 0;

$pending_count = max(0, $total_required - $assigned_count);

/* ===============================
   FETCH PENDING HOSTEL STUDENTS
================================ */
$students = mysqli_query($conn,"
    SELECT student_id, student_name, reg_no, course_code
    FROM students
    WHERE hostel_required='Yes'
    AND student_id NOT IN (
        SELECT student_id FROM hostel_fee_assign
    )
    ORDER BY student_name
");

/* ===============================
   FETCH HOSTEL FEE HEADS
================================ */
$hostel_heads = mysqli_query($conn,"
    SELECT head_id, head_name, default_amount
    FROM fee_head
    WHERE fee_code LIKE 'H%'
");

/* ===============================
   SAVE HOSTEL FEES
================================ */
if (isset($_POST['assign'])) {

    $student_id = $_POST['student_id'];
    $block      = $_POST['block'];
    $room       = $_POST['room'];
    $bed        = $_POST['bed'];

    // Save hostel allocation
    mysqli_query($conn,"
        INSERT IGNORE INTO hostel
        (student_id, block, room_no, bed_no)
        VALUES
        ('$student_id','$block','$room','$bed')
    ");

    foreach($_POST['amount'] as $head_id => $amt){
        $amt = (float)$amt;
        if($amt > 0){
            mysqli_query($conn,"
                INSERT INTO hostel_fee_assign
                (student_id, head_id, amount)
                VALUES
                ('$student_id','$head_id','$amt')
            ");
        }
    }

    header("Location: hostel_fee_assign.php?success=1");
    exit();
}

/* ===============================
   FETCH ASSIGNED HOSTEL STUDENTS
================================ */
$assigned_students = mysqli_query($conn,"
    SELECT 
        s.reg_no,
        s.student_name,
        s.course_code,
        h.block,
        h.room_no,
        h.bed_no,
        SUM(f.amount) AS total_fee
    FROM hostel_fee_assign f
    JOIN students s ON s.student_id = f.student_id
    LEFT JOIN hostel h ON h.student_id = s.student_id
    GROUP BY f.student_id
    ORDER BY s.student_name
");
?>
<!DOCTYPE html>
<html>
<head>
<title>Hostel Fee Assignment</title>
<style>
body{font-family:Arial;background:#f4f6f9;}
.container{max-width:1200px;margin:40px auto;}
.card{background:#fff;padding:25px;border-radius:8px;margin-bottom:30px;}
.summary{display:flex;gap:20px;margin-bottom:20px;}
.summary div{flex:1;padding:15px;border-radius:8px;text-align:center;}
table{width:100%;border-collapse:collapse;margin-top:10px;}
th{background:#2c3e50;color:#fff;padding:10px;}
td{padding:8px;border:1px solid #ddd;text-align:center;}
input{padding:6px;width:100%;}
button{padding:6px 12px;background:#8e44ad;color:#fff;border:none;cursor:pointer;}
.success{background:#e8f7ee;color:#1e8449;padding:10px;margin-bottom:15px;}
</style>
</head>
<body>

<div class="container">

<div class="card">
<h3>🏨 Hostel Fee Assignment</h3>
<?php if(isset($_GET['success'])) echo "<div class='success'>✅ Hostel fees assigned successfully</div>"; ?>

<div class="summary">
    <div><h4>Hostel Required</h4><h2><?= $total_required ?></h2></div>
    <div><h4>Assigned</h4><h2><?= $assigned_count ?></h2></div>
    <div><h4>Pending</h4><h2><?= $pending_count ?></h2></div>
</div>

<h4>🕒 Pending Hostel Students</h4>

<table>
<tr>
    <th>Reg No</th>
    <th>Name</th>
    <th>Dept</th>
    <th>Block</th>
    <th>Room</th>
    <th>Bed</th>
    <th>Fee Head</th>
    <th>Amount (₹)</th>
    <th>Action</th>
</tr>

<?php while($s = mysqli_fetch_assoc($students)){ 
mysqli_data_seek($hostel_heads,0);
$rowspan = mysqli_num_rows($hostel_heads);
$first = true;
while($h = mysqli_fetch_assoc($hostel_heads)){ ?>
<tr>
<form method="post">

<?php if($first){ ?>
<td rowspan="<?= $rowspan ?>"><?= $s['reg_no'] ?></td>
<td rowspan="<?= $rowspan ?>"><?= $s['student_name'] ?></td>
<td rowspan="<?= $rowspan ?>"><?= $s['course_code'] ?></td>
<td rowspan="<?= $rowspan ?>"><input name="block" required></td>
<td rowspan="<?= $rowspan ?>"><input name="room" required></td>
<td rowspan="<?= $rowspan ?>"><input name="bed" required></td>
<?php } ?>

<td><?= $h['head_name'] ?></td>
<td>
<input type="number" name="amount[<?= $h['head_id'] ?>]"
       value="<?= $h['default_amount'] ?>" required>
</td>

<?php if($first){ ?>
<td rowspan="<?= $rowspan ?>">
<input type="hidden" name="student_id" value="<?= $s['student_id'] ?>">
<button name="assign">Assign</button>
</td>
<?php } ?>

</form>
</tr>
<?php $first=false; } } ?>
</table>
</div>

<div class="card">
<h3>📋 Hostel Assigned Students</h3>
<table>
<tr>
<th>Reg No</th><th>Name</th><th>Dept</th>
<th>Block</th><th>Room</th><th>Bed</th>
<th>Total Hostel Fee (₹)</th>
</tr>

<?php if(mysqli_num_rows($assigned_students)>0){
while($a=mysqli_fetch_assoc($assigned_students)){ ?>
<tr>
<td><?= $a['reg_no'] ?></td>
<td><?= $a['student_name'] ?></td>
<td><?= $a['course_code'] ?></td>
<td><?= $a['block'] ?? '-' ?></td>
<td><?= $a['room_no'] ?? '-' ?></td>
<td><?= $a['bed_no'] ?? '-' ?></td>
<td><b>₹ <?= number_format($a['total_fee'],2) ?></b></td>
</tr>
<?php }} else { ?>
<tr><td colspan="7">No hostel fees assigned yet</td></tr>
<?php } ?>
</table>
</div>

<a href="/fees_management_system/admin/dashboard.php">⬅ Back to Dashboard</a>
</div>
</body>
</html>
