<?php
session_start();
if(!isset($_SESSION['role']) || $_SESSION['role'] != 'STUDENT'){
    die("Access Denied");
}

include "../config/db.php";

/* Student id is VARCHAR like CSE2202 */
$student_id = mysqli_real_escape_string($conn, $_SESSION['student_id']);

/* ===============================
   1. GET STUDENT COURSE
================================ */
$st = mysqli_fetch_assoc(mysqli_query($conn,"
SELECT course_code 
FROM students 
WHERE student_id = '$student_id'
"));

$course = $st['course_code'] ?? '';

/* ===============================
   2. GET LATEST ACADEMIC YEAR & SEM
   (from admin fee structure)
================================ */
$ys = mysqli_fetch_assoc(mysqli_query($conn,"
SELECT academic_year, semester
FROM fee_structure_detail
WHERE course = '$course'
ORDER BY academic_year DESC, semester DESC
LIMIT 1
"));

$academic_year = $ys['academic_year'] ?? 1;
$semester      = $ys['semester'] ?? 1;

/* ===============================
   3. GET CONCESSIONS (student based)
================================ */
$cq = mysqli_query($conn,"
SELECT concession_type, concession_amount, approved_by, approved_date
FROM concession
WHERE student_id = '$student_id'
ORDER BY approved_date DESC
");
?>

<!DOCTYPE html>
<html>
<head>
<title>View Concession | Student</title>

<style>
body{
    margin:0;
    font-family:Segoe UI, Arial;
    background:#f4f6f9;
}
.header{
    background:#2c3e50;
    color:#fff;
    padding:15px 25px;
    font-size:20px;
}
.wrapper{
    display:flex;
}
.sidebar{
    width:230px;
    background:#34495e;
    min-height:100vh;
}
.sidebar a{
    display:block;
    color:#ecf0f1;
    padding:12px 20px;
    text-decoration:none;
}
.sidebar a:hover{
    background:#1abc9c;
}
.content{
    flex:1;
    padding:30px;
}
.card{
    background:#fff;
    padding:25px;
    border-radius:8px;
    box-shadow:0 2px 6px rgba(0,0,0,0.15);
    max-width:700px;
}
table{
    width:100%;
    border-collapse:collapse;
    margin-top:15px;
}
th, td{
    border:1px solid #ddd;
    padding:10px;
    text-align:center;
}
th{
    background:#2c3e50;
    color:#fff;
}
.empty{
    color:#777;
    margin-top:10px;
}
</style>
</head>

<body>

<div class="header">
    Fee Management System – Student Panel
</div>

<div class="wrapper">

<!-- SIDEBAR -->
<div class="sidebar">
    <a href="dashboard.php">🏠 Dashboard</a>
    <a href="view_concession.php" style="background:#1abc9c">📄 Concession</a>
    <a href="view_fine.php">📄 Fine</a>
    <a href="pay_fee.php">💳 Pay Fees</a>
    <a href="../auth/logout.php">🚪 Logout</a>
</div>

<!-- CONTENT -->
<div class="content">

<div class="card">
<h3>Concession Details (Year <?= $academic_year ?> | Sem <?= $semester ?>)</h3>

<?php if(mysqli_num_rows($cq) > 0){ ?>
<table>
<tr>
    <th>Type</th>
    <th>Amount</th>
    <th>Approved By</th>
    <th>Approved Date</th>
</tr>

<?php while($c = mysqli_fetch_assoc($cq)){ ?>
<tr>
    <td><?= htmlspecialchars($c['concession_type']) ?></td>
    <td>₹<?= number_format($c['concession_amount'],2) ?></td>
    <td><?= htmlspecialchars($c['approved_by']) ?></td>
    <td><?= $c['approved_date'] ?></td>
</tr>
<?php } ?>

</table>
<?php } else { ?>
    <p class="empty">No concession applied for this semester.</p>
<?php } ?>

</div>

</div>
</div>

</body>
</html>
