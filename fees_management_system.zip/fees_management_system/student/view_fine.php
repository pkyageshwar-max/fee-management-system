<?php
session_start();
if($_SESSION['role']!='STUDENT') die("Access Denied");
include "../config/db.php";

/* student_id is STRING */
$student_id = mysqli_real_escape_string($conn, $_SESSION['student_id']);

/* ===============================
   FETCH FINES (DIRECT BY STUDENT)
================================ */
$fq = mysqli_query($conn,"
SELECT fine_reason, fine_amount, fine_date, status
FROM fine
WHERE student_id = '$student_id'
ORDER BY fine_date DESC
");

$fines = [];
$total_fine = 0;

while($f = mysqli_fetch_assoc($fq)){
    $fines[] = $f;
    if($f['status']=='UNPAID'){
        $total_fine += $f['fine_amount'];
    }
}
?>
<!DOCTYPE html>
<html>
<head>
<title>View Fine | Student</title>
<style>
body{margin:0;font-family:Segoe UI,Arial;background:#f4f6f9}
.header{background:#2c3e50;color:#fff;padding:15px 25px;font-size:20px}
.wrapper{display:flex}
.sidebar{width:230px;background:#34495e;min-height:100vh}
.sidebar a{display:block;color:#ecf0f1;padding:12px 20px;text-decoration:none}
.sidebar a:hover{background:#1abc9c}
.content{flex:1;padding:30px}
.card{background:#fff;padding:25px;border-radius:8px;box-shadow:0 2px 6px rgba(0,0,0,0.15);max-width:800px}
table{width:100%;border-collapse:collapse;margin-top:15px}
th{background:#2c3e50;color:#fff;padding:10px}
td{padding:10px;border:1px solid #ddd;text-align:center}
.paid{color:green;font-weight:bold}
.unpaid{color:red;font-weight:bold}
.summary{margin-top:15px;font-size:16px}
.empty{color:green;font-weight:bold}
</style>
</head>

<body>

<div class="header">Fee Management System – Student Panel</div>

<div class="wrapper">

<div class="sidebar">
    <a href="dashboard.php">🏠 Dashboard</a>
    <a href="view_concession.php">📄 Concession</a>
    <a href="view_fine.php" style="background:#1abc9c">📄 Fine</a>
    <a href="pay_fee.php">💳 Pay Fees</a>
    <a href="../auth/logout.php">🚪 Logout</a>
</div>

<div class="content">
<div class="card">
<h3>Fine Details</h3>

<?php if(count($fines)==0): ?>
    <p class="empty">No fine imposed.</p>
<?php else: ?>
<table>
<tr>
    <th>Reason</th>
    <th>Amount</th>
    <th>Date</th>
    <th>Status</th>
</tr>

<?php foreach($fines as $f): ?>
<tr>
    <td><?= htmlspecialchars($f['fine_reason']) ?></td>
    <td>₹<?= number_format($f['fine_amount'],2) ?></td>
    <td><?= $f['fine_date'] ?></td>
    <td class="<?= strtolower($f['status']) ?>"><?= $f['status'] ?></td>
</tr>
<?php endforeach; ?>
</table>

<p class="summary"><b>Total Unpaid Fine: ₹<?= number_format($total_fine,2) ?></b></p>
<?php endif; ?>

</div>
</div>
</div>

</body>
</html>
