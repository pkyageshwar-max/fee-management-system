<?php
session_start();

if (!isset($_SESSION['role']) || $_SESSION['role'] !== 'STUDENT') {
    header("Location: login.php");
    exit();
}

include "../config/db.php";

$student_id = mysqli_real_escape_string($conn,$_SESSION['student_id']);

/* STUDENT INFO */

$stu_q=mysqli_query($conn,"
SELECT student_id,student_name,course_code,reg_no
FROM students
WHERE student_id='$student_id'
LIMIT 1");

if(mysqli_num_rows($stu_q)==0){
die("Student not found");
}

$student=mysqli_fetch_assoc($stu_q);

/* ===============================
ACADEMIC FEE
===============================*/

$academic_fee=0;

$fee_q=mysqli_query($conn,"
SELECT IFNULL(SUM(amount),0) total
FROM fee_structure_detail
WHERE course='{$student['course_code']}'");

if($fee_q){
$academic_fee=(float)mysqli_fetch_assoc($fee_q)['total'];
}

/* HOSTEL */

$hostel_fee = 0;

$hq=mysqli_query($conn,"
SELECT amount
FROM hostel_fee_assign
WHERE student_id='$student_id'");

if($hq){

while($h=mysqli_fetch_assoc($hq)){

$hostel_fee += (float)$h['amount'];

}

}

/* ===============================
   TRANSPORT FEES
================================ */

$transport_fee = 0;

$tq = mysqli_query($conn,"
SELECT transport_fee, status
FROM transport_fee_assign
WHERE student_id = '$student_id'
");

if($tq && mysqli_num_rows($tq) > 0){

    while($t = mysqli_fetch_assoc($tq)){

        if(strtolower($t['status'])!='paid'){

            $transport_fee += (float)$t['transport_fee'];

        }

    }

}

/* IMPORTANT SAFE CHECK */

if($tq && mysqli_num_rows($tq) > 0){

    while($t = mysqli_fetch_assoc($tq)){

        $transport_rows[] = $t;

        $transport_fee += (float)$t['amount'];

    }

}

/* CONCESSION */

$concession=0;

$cq=mysqli_query($conn,"
SELECT IFNULL(SUM(concession_amount),0) c
FROM concession
WHERE student_id='$student_id'");

$concession=(float)mysqli_fetch_assoc($cq)['c'];


/* FINE */

$fine=0;

$fq=mysqli_query($conn,"
SELECT IFNULL(SUM(fine_amount),0) f
FROM fine
WHERE student_id='$student_id'
AND status='UNPAID'");

$fine=(float)mysqli_fetch_assoc($fq)['f'];


/* PAID AMOUNT */

$paid=0;

$pq=mysqli_query($conn,"
SELECT IFNULL(SUM(total_amount),0) p
FROM payment
WHERE student_id='$student_id'
AND status IN('PAID','Paid')
");

$paid=(float)mysqli_fetch_assoc($pq)['p'];


/* FINAL */

$total_fee=$academic_fee+$hostel_fee+$transport_fee;

$payable=($total_fee-$concession)+$fine;

$pending=max(0,round($payable-$paid,2));

?>

<!DOCTYPE html>
<html>
<head>

<title>Pay Fees</title>

<style>

body{
margin:0;
font-family:Segoe UI;
background:#f4f6f9;
}

.card{
background:#fff;
padding:25px;
width:420px;
margin:80px auto;
border-radius:8px;
box-shadow:0 2px 8px rgba(0,0,0,.2);
}

.row{
display:flex;
justify-content:space-between;
margin:8px 0;
}

.total{
font-size:18px;
font-weight:bold;
color:green;
}

button{

width:100%;
padding:12px;
background:#27ae60;
color:#fff;
border:none;
border-radius:5px;
font-size:18px;
cursor:pointer;

}

button:hover{

background:#1e8449;

}

.back{

text-align:center;
display:block;
margin-top:15px;
color:#2980b9;
font-weight:bold;

}

</style>

</head>

<body>

<div class="card">

<h3>Fee Payment</h3>

<b><?=htmlspecialchars($student['student_name'])?></b>

<div class="row">

<span>Course</span>

<b><?=htmlspecialchars($student['course_code'])?></b>

</div>

<hr>

<div class="row total">

<span>Net Payable</span>

<span>₹<?=number_format($pending,2)?></span>

</div>


<?php if($pending>0): ?>

<input type="number"

id="amount"

min="1"

max="<?=$pending?>"

value="<?=$pending?>"

style="width:100%;padding:10px;margin:8px 0;">


<button onclick="payNow()">💳 Pay Now</button>


<script>

/* ===== SIMULATED RAZORPAY ===== */

function payNow(){

let amount=document.getElementById("amount").value;

if(amount<=0){

alert("Invalid Amount");

return;

}

/* Razorpay Popup Simulation */

let confirmPay=confirm(

"RAZORPAY PAYMENT GATEWAY\n\n"+

"College Fee Payment\n\n"+

"Amount ₹"+amount+"\n\n"+

"Click OK to Pay."

);

if(!confirmPay){

alert("Payment Cancelled");

return;

}

/* Fake Razorpay IDs */

let pid="pay_"+Date.now();

let oid="order_"+Math.floor(Math.random()*999999);

let sig="sig_"+Math.floor(Math.random()*999999);

/* Redirect */

window.location.href=

"process_payment.php?pid="+pid+

"&oid="+oid+

"&sig="+sig+

"&amt="+amount;

}

</script>


<?php else: ?>

<p style="color:green;text-align:center;font-weight:bold;">

All fees paid ✅

</p>

<?php endif; ?>


<a href="dashboard.php" class="back">

⬅ Back to Dashboard

</a>

</div>

</body>

</html>