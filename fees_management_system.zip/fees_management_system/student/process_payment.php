<?php
session_start();

if(!isset($_SESSION['role']) || $_SESSION['role']!='STUDENT'){
die("Access Denied");
}

include "../config/db.php";


/* ========= VALIDATE ========= */

if(!isset($_GET['pid'],$_GET['amt'],$_GET['oid'],$_GET['sig'])){
die("Invalid Payment Access");
}

$student_id=$_SESSION['student_id'];

$payment_id=$_GET['pid'];
$order_id=$_GET['oid'];
$amount=(float)$_GET['amt'];

if($amount<=0){
die("Invalid Amount");
}


/* ========= RECEIPT ========= */

$receipt="REC".time();
$date=date("Y-m-d");


/* ========= GET STUDENT DETAILS ========= */

$stu=mysqli_fetch_assoc(mysqli_query($conn,"
SELECT course_code,current_year,current_semester
FROM students
WHERE student_id='$student_id'
"));

$course=$stu['course_code'];
$year=$stu['current_year'];
$sem=$stu['current_semester'];


/* ========= DEFAULT BREAKUP ========= */

$tuition_paid=0;
$exam_paid=0;
$maintenance_paid=0;
$library_paid=0;
$misc_paid=0;
$transport_paid=0;
$hostel_paid=0;


/* ========= GET FEE STRUCTURE ========= */
$fq=mysqli_query($conn,"
SELECT fh.head_name,fsd.amount
FROM fee_structure_detail fsd
JOIN fee_head fh
ON fh.head_id=fsd.head_id
");
if(!$fq){
die(mysqli_error($conn));
}

while($f=mysqli_fetch_assoc($fq)){

switch(trim($f['head_name'])){

case 'Tuition Fee':
$tuition_paid+=(float)$f['amount'];
break;

case 'Exam Fee':
$exam_paid+=(float)$f['amount'];
break;

case 'Maintenance':
$maintenance_paid+=(float)$f['amount'];
break;

case 'Library Fee':
$library_paid+=(float)$f['amount'];
break;

case 'Miscellaneous':
$misc_paid+=(float)$f['amount'];
break;

}

}


/* ========= HOSTEL ========= */

$hq=mysqli_query($conn,"
SELECT fee_amount,fee_status
FROM hostel
WHERE student_id='$student_id'
LIMIT 1
");

if(mysqli_num_rows($hq)>0){

$h=mysqli_fetch_assoc($hq);

if($h['fee_status']=='Pending'){

$hostel_paid=(float)$h['fee_amount'];

}

}


/* ========= SAVE PAYMENT ========= */

mysqli_query($conn,"

INSERT INTO payment(

student_id,

tuition_paid,
exam_paid,
maintenance_paid,
library_paid,
misc_paid,
hostel_paid,
transport_paid,

total_amount,

payment_mode,
transaction_id,
receipt_no,
payment_date,
status

)

VALUES(

'$student_id',

'$tuition_paid',
'$exam_paid',
'$maintenance_paid',
'$library_paid',
'$misc_paid',
'$hostel_paid',
'$transport_paid',

'$amount',

'RAZORPAY',
'$payment_id',
'$receipt',
'$date',

'Paid'

)

");


/* ========= UPDATE HOSTEL ========= */

if($hostel_paid>0){

mysqli_query($conn,"
UPDATE hostel
SET fee_status='Paid'
WHERE student_id='$student_id'
");

}


/* ========= FINES ========= */

mysqli_query($conn,"
UPDATE fine
SET status='PAID'
WHERE student_id='$student_id'
AND status='UNPAID'
");


/* ========= SMS ========= */

$st=mysqli_fetch_assoc(mysqli_query($conn,"
SELECT student_name,phone
FROM students
WHERE student_id='$student_id'
"));

$name=$st['student_name'] ?? 'Student';
$phone=$st['phone'] ?? '';

$msg="Dear $name, your fee payment of Rs.$amount is successful. Receipt No: $receipt.";

mysqli_query($conn,"
INSERT INTO smslog(student_id,phone_no,message,status)
VALUES(
'$student_id',
'$phone',
'".mysqli_real_escape_string($conn,$msg)."',
'SENT'
)
");


header("Location: dashboard.php?payment=success");

exit;

?>