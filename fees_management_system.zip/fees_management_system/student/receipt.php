<?php
session_start();

if(!isset($_SESSION['role']) || $_SESSION['role']!='STUDENT'){
    die("Access Denied");
}

include "../config/db.php";

if(!isset($_GET['id'])){
    die("Invalid Receipt Request");
}

$payment_id=(int)$_GET['id'];

$student_id=mysqli_real_escape_string($conn,$_SESSION['student_id']);

$q=mysqli_query($conn,"
SELECT 
p.receipt_no,
p.payment_date,
p.total_amount,
p.payment_mode,
p.transaction_id,
s.student_name,
s.reg_no,
s.course_code
FROM payment p
JOIN students s ON s.student_id=p.student_id
WHERE p.payment_id='$payment_id'
AND p.student_id='$student_id'
LIMIT 1
");

if(mysqli_num_rows($q)==0){
die("Receipt Not Found");
}

$r=mysqli_fetch_assoc($q);
?>

<!DOCTYPE html>
<html>
<head>

<title>Fee Receipt</title>

<style>

body{

font-family:Segoe UI;
background:#f4f6f9;
margin:0;

}

/* CENTER PAGE */

.wrapper{

width:100%;
display:flex;
justify-content:center;
margin-top:40px;

}


/* RECEIPT BOX */

.receipt{

width:780px;
background:#fff;

border:1px solid #999;

padding:30px;

}


/* HEADER */

.header{

display:flex;
align-items:center;
gap:20px;

border-bottom:2px solid #000;

padding-bottom:10px;

margin-bottom:20px;

}

.header img{

height:70px;

}


.header h2{

margin:0;
text-align:center;
flex:1;

}

.header p{

text-align:center;
margin:3px 0;

font-weight:bold;

}


/* TABLE */

table{

width:100%;

border-collapse:collapse;

}


td{

padding:10px 6px;

border-bottom:1px solid #ddd;

}


.label{

width:25%;

font-weight:bold;

}


.value{

width:25%;

}


/* FOOTER */

.footer{

margin-top:30px;

}


.btn{

background:#27ae60;

color:#fff;

padding:10px 20px;

border:none;

cursor:pointer;

font-weight:bold;

border-radius:4px;

}


/* PRINT */

@media print{

.btn{

display:none;

}

body{

background:#fff;

}

}

</style>

</head>

<body>

<div class="wrapper">

<div class="receipt">

<!-- HEADER -->

<div class="header">

<img src="../assets/images/college_logo.png">

<div style="flex:1">

<h2>Nanjiah Lingammal Polytechnic College</h2>

<p>OFFICIAL FEE RECEIPT</p>

</div>

</div>



<table>

<tr>

<td class="label">Receipt No</td>

<td class="value"><?= $r['receipt_no'] ?></td>

<td class="label">Date</td>

<td><?= $r['payment_date'] ?></td>

</tr>


<tr>

<td class="label">Name</td>

<td><?= $r['student_name'] ?></td>

<td class="label">Reg No</td>

<td><?= $r['reg_no'] ?></td>

</tr>


<tr>

<td class="label">Course</td>

<td><?= $r['course_code'] ?></td>

<td class="label">Payment Mode</td>

<td><?= $r['payment_mode'] ?></td>

</tr>


<tr>

<td class="label">Transaction ID</td>

<td><?= $r['transaction_id'] ?></td>

<td class="label">Amount Paid</td>

<td>

₹<?= number_format($r['total_amount'],2) ?>

</td>

</tr>

</table>


<div class="footer">

<p><b>Received with thanks.</b></p>

<p>Office Seal & Signature</p>

<br>

<button class="btn" onclick="window.print()">

🖨 Print / Save as PDF

</button>

</div>

</div>

</div>

</body>

</html>