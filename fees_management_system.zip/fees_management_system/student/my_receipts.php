<?php
session_start();

if(!isset($_SESSION['role']) || $_SESSION['role']!='STUDENT'){
    die("Access Denied");
}

include "../config/db.php";

if(!isset($_GET['id'])){
    die("Invalid Receipt Request");
}

$payment_id=(int)$_GET['id'];

$student_id=mysqli_real_escape_string($conn,$_SESSION['student_id']);

$q=mysqli_query($conn,"
SELECT 
p.receipt_no,
p.payment_date,
p.total_amount,
p.payment_mode,
p.transaction_id,
s.student_name,
s.reg_no,
s.course_code
FROM payment p
JOIN students s ON s.student_id=p.student_id
WHERE p.payment_id='$payment_id'
AND p.student_id='$student_id'
LIMIT 1
");

if(mysqli_num_rows($q)==0){
    die("Receipt not found or unauthorized access");
}

$r = mysqli_fetch_assoc($q);
?>

<!DOCTYPE html>
<html>
<head>
<title>Fee Receipt</title>

<style>
    .header{
display:flex;
align-items:center;
border-bottom:2px solid #000;
padding-bottom:10px;
gap:15px;
}

.logo img{
height:70px;
width:auto;
}

.college-name{
flex:1;
text-align:center;
}

.college-name h2{
margin:0;
}

.college-name p{
margin:0;
}
body{font-family:Segoe UI;background:#f4f6f9;}
.receipt{
    width:750px;
    margin:40px auto;
    background:#fff;
    padding:30px;
    border:1px solid #333;
}
.header{text-align:center;border-bottom:2px solid #000;padding-bottom:10px;}
.row{display:flex;justify-content:space-between;margin:6px 0;}
hr{margin:15px 0;}

.btn-area{margin-top:20px;display:flex;gap:15px;}
.btn{
    padding:10px 20px;
    border:none;
    cursor:pointer;
    font-weight:bold;
    border-radius:4px;
}
.print{background:#27ae60;color:#fff;}
.download{background:#2980b9;color:#fff;}

@media print {
    .btn-area{display:none;}
}
</style>
</head>

<body>

<div class="receipt" id="printArea">
<div class="header">

<div class="logo">
<img src="../assets/images/college_logo.png" alt="College Logo">
</div>

<div class="college-name">
<h2>Nanjiah Lingammal Polytechnic College</h2>
<p><b>OFFICIAL FEE RECEIPT</b></p>
</div>

</div>

<div class="row"><b>Receipt No:</b> <?= $r['receipt_no'] ?></div>
<div class="row"><b>Date:</b> <?= $r['payment_date'] ?></div>

<hr>

<div class="row">
<span><b>Name:</b> <?= $r['student_name'] ?></span>
<span><b>Reg No:</b> <?= $r['reg_no'] ?></span>
</div>

<div class="row">
<span><b>Course:</b> <?= $r['course_code'] ?></span>
</div>

<hr>

<div class="row"><b>Payment Mode:</b> <?= $r['payment_mode'] ?></div>
<div class="row"><b>Transaction ID:</b> <?= $r['transaction_id'] ?></div>
<div class="row"><b>Amount Paid:</b> ₹<?= number_format($r['total_amount'],2) ?></div>

<hr>

<p><b>Received with thanks.</b></p>
<p>Office Seal & Signature</p>

<div class="btn-area">
    <button class="btn download" onclick="window.print()">⬇ Download PDF</button>
</div>
</div>

<a href="dashboard.php" class="back">⬅ Back to Dashboard</a>

</body>
</html>
