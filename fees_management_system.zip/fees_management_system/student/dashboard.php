<?php
session_start();

if (!isset($_SESSION['role']) || $_SESSION['role'] != 'STUDENT') {
    header("Location: ../auth/login.php");
    exit();
}

include "../config/db.php";

$student_id = mysqli_real_escape_string($conn, $_SESSION['student_id']);

/* ===============================
   1. GET STUDENT BASIC DETAILS
================================ */
$q = mysqli_query($conn, "
    SELECT student_id, student_name, course_code, reg_no
    FROM students
    WHERE student_id = '$student_id'
    LIMIT 1
");

$data = mysqli_fetch_assoc($q);
if(!$data){
    die("<div style='padding:20px;color:red;'>Student not found.</div>");
}

$course = $data['course_code'];

/* ===============================
   2. GET LATEST ACADEMIC YEAR & SEMESTER FROM FEE STRUCTURE
================================ */
$period_q = mysqli_query($conn, "
    SELECT academic_year, semester
    FROM fee_structure_detail
    WHERE course = '$course'
    ORDER BY academic_year DESC, semester DESC
    LIMIT 1
");

$period = mysqli_fetch_assoc($period_q);

$academic_year = $period['academic_year'] ?? 1;
$semester      = $period['semester'] ?? 1;

/* ===============================
   3. ACADEMIC FEE BREAKDOWN
================================ */
$academic_fee = 0;
$fee_rows = [];

$fq = mysqli_query($conn,"
    SELECT fh.head_name, fsd.amount
    FROM fee_structure_detail fsd
    JOIN fee_head fh ON fsd.head_id = fh.head_id
    WHERE fsd.course = '$course'
    AND fsd.academic_year = '$academic_year'
    AND fsd.semester = '$semester'
");

while($r = mysqli_fetch_assoc($fq)){
    $fee_rows[] = $r;
    $academic_fee += (float)$r['amount'];
}

/* ===============================
   4. HOSTEL FEE (HEAD-WISE)
================================ */

$hostel_fee = 0;
$hostel_status = "Not Assigned";
$hostel_rows = [];

$hostel_q = mysqli_query($conn,"
    SELECT fh.head_name, hfa.amount
    FROM hostel_fee_assign hfa
    JOIN fee_head fh ON fh.head_id = hfa.head_id
    WHERE hfa.student_id = '$student_id'
");


if($hostel_q && mysqli_num_rows($hostel_q) > 0){
   while($h = mysqli_fetch_assoc($hostel_q)){
    $hostel_rows[] = $h;
    $hostel_fee += (float)$h['amount'];
}

if($hostel_fee > 0){
    $hostel_status = "Assigned";
}

}
/* ===============================
   4B. TRANSPORT FEE (HEAD-WISE)
================================ */

$transport_fee = 0;
$transport_status = "Not Assigned";
$transport_rows = [];

$transport_q = mysqli_query($conn,"
    SELECT t.route_name, f.transport_fee, f.status
    FROM transport_fee_assign f
    JOIN transport t ON t.transport_id = f.transport_id
    WHERE f.student_id = '$student_id'
");

if($transport_q && mysqli_num_rows($transport_q) > 0){
    while($t = mysqli_fetch_assoc($transport_q)){
        $transport_rows[] = $t;
        $transport_fee += (float)$t['transport_fee'];
        $transport_status = $t['status'];
    }
}


/* ===============================
   5. CONCESSION, FINE, PAYMENT (USING STUDENT_ID)
================================ */
$concession = mysqli_fetch_assoc(mysqli_query($conn,"
    SELECT IFNULL(SUM(concession_amount),0) AS c 
    FROM concession WHERE student_id='$student_id'
"))['c'];

$fine = mysqli_fetch_assoc(mysqli_query($conn,"
    SELECT IFNULL(SUM(fine_amount),0) AS f 
    FROM fine WHERE student_id='$student_id' AND status='UNPAID'
"))['f'];

$paid = mysqli_fetch_assoc(mysqli_query($conn,"
SELECT IFNULL(SUM(total_amount),0) AS p 
FROM payment 
WHERE student_id='$student_id' AND status='PAID'
"))['p'];

/* ===============================
   6. FINAL CALCULATION
================================ */
$total_fee = $academic_fee + $hostel_fee + $transport_fee;
$payable   = ($total_fee - $concession) + $fine;
$pending   = $payable - $paid;
?>


<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>Student Dashboard | NLPC</title>
<style>
    
    body{margin:0; font-family:"Segoe UI", Arial, sans-serif; background:#f4f6f9; color:#333;}
    .header{background:#2c3e50; color:#fff; padding:15px 25px; display:flex; gap:15px; align-items:center;}
    .header img{height:50px; background:#fff; border-radius:4px; padding:2px;}
    .wrapper{display:flex;}
    .sidebar{width:240px; background:#34495e; min-height:100vh;}
    .sidebar a{display:block; color:#bdc3c7; padding:15px 20px; text-decoration:none; border-bottom:1px solid #2c3e50; transition:0.3s;}
    .sidebar a:hover{background:#1abc9c; color:#fff;}
    .content{flex:1; padding:30px;}
    .card{background:#fff; padding:25px; border-radius:8px; box-shadow:0 2px 8px rgba(0,0,0,0.1); margin-bottom:20px;}
    .card h3{margin-top:0; border-bottom:2px solid #f4f6f9; padding-bottom:10px; color:#2c3e50;}
    table{width:100%; border-collapse:collapse; margin-top:10px;}
    table th{background:#ecf0f1; color:#2c3e50; padding:12px; text-align:left; border:1px solid #ddd;}
    table td{padding:12px; border:1px solid #ddd;}
    .status-box{display:flex; justify-content:space-between; align-items:center; padding:15px; border-radius:5px; margin-top:10px;}
    .success-bg{background:#d4edda; color:#155724; border:1px solid #c3e6cb;}
    .error-bg{background:#f8d7da; color:#721c24; border:1px solid #f5c6cb;}
    .amount-val{font-weight:bold; font-size:1.1em;}
</style>
</head>
<body>

<div class="header">
    <img src="../assets/images/college_logo.png" alt="Logo">
    <div>
        <h2 style="margin:0; font-size:22px;">Nanjiah Lingammal Polytechnic College</h2>
        <p style="margin:0; opacity:0.8;">Student Portal - Fee Management</p>
    </div>
</div>

<div class="wrapper">
    <div class="sidebar">
        <a href="dashboard.php">🏠 Dashboard</a>
        <a href="view_concession.php">📄 My Concessions</a>
        <a href="view_fine.php">📄 Fine History</a>
        <a href="fee_statement.php">Fees Statement</a>
        <a href="pay_fee.php">💳 Pay Online</a>
        <a href="../auth/logout.php" style="color:#e74c3c;">🚪 Logout</a>
    </div>

    <div class="content">

        <div class="card">
            <h3>Welcome, <?= htmlspecialchars($data['student_name']) ?></h3>
            <p><b>Student ID:</b> <?= htmlspecialchars($data['student_id']) ?></p>
            <p><b>Course:</b> <?= htmlspecialchars($data['course_code']) ?></p>
            <p><b>Current Status:</b> Year <?= $academic_year ?> | Semester <?= $semester ?></p>
            <p><b>Hostel Status:</b> <?= $hostel_status ?></p>
            <p><b>Transport Status:</b> <?= $transport_status ?></p>
        </div>

        <div class="card">
            <h3>Fee Particulars</h3>
           <?php if(count($fee_rows) > 0 || $hostel_fee > 0 || $transport_fee > 0): ?>
                <table>
                    <tr><th>Description</th><th>Amount</th></tr>

                    <?php foreach($fee_rows as $f): ?>
                    <tr>
                        <td><?= htmlspecialchars($f['head_name']) ?></td>
                        <td>₹<?= number_format($f['amount'], 2) ?></td>
                    </tr>
                    <?php endforeach; ?>

                    <?php if($hostel_fee > 0): ?>
                    <tr>
                        <td>Hostel Fee</td>
                        <td>₹<?= number_format($hostel_fee, 2) ?></td>
                    </tr>
                    <?php endif; ?>
                    <?php if($transport_fee > 0): ?>
<tr>
    <td>Transport Fee (<?= htmlspecialchars($transport_rows[0]['route_name'] ?? '') ?>)</td>
    <td>₹<?= number_format($transport_fee, 2) ?></td>
</tr>
<?php endif; ?>

                    <tr style="background:#f8f9fa; font-weight:bold;">
                        <td>Total Institutional Fee</td>
                        <td>₹<?= number_format($total_fee, 2) ?></td>
                    </tr>
                </table>
            <?php else: ?>
                <p style="color:gray">Your fee structure has not been defined for this semester.</p>
            <?php endif; ?>
        </div>

        <div class="card">
            <h3>Account Summary</h3>
            <p>Institutional Total: <span class="amount-val">₹<?= number_format($total_fee, 2) ?></span></p>
            <p>Scholarship/Concession: <span class="amount-val" style="color:green;">-₹<?= number_format($concession, 2) ?></span></p>
            <p>Applicable Fines: <span class="amount-val" style="color:red;">+₹<?= number_format($fine, 2) ?></span></p>
            <hr>
            <p style="font-size:1.2em;">Net Payable: <b>₹<?= number_format($payable, 2) ?></b></p>
            <p>Paid Till Date: <span class="amount-val" style="color:#2980b9;">₹<?= number_format($paid, 2) ?></span></p>

            <?php if($pending <= 0): ?>
                <div class="status-box success-bg">
                    <span>Status: <b>FULLY PAID</b></span>
                    <span>No outstanding dues.</span>
                </div>
            <?php else: ?>
                <div class="status-box error-bg">
                    <span>Status: <b>PENDING DUES</b></span>
                    <span class="amount-val">Amount: ₹<?= number_format($pending, 2) ?></span>
                </div>
                <div style="margin-top:15px; text-align:right;">
                    <a href="pay_fee.php" style="background:#27ae60; color:#fff; padding:10px 20px; text-decoration:none; border-radius:4px; font-weight:bold;">Pay Balance Now</a>
                </div>
            <?php endif; ?>
        </div>

    </div>
</div>

</body>
</html>
