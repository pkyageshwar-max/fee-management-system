<?php
session_start();

if(!isset($_SESSION['role']) || $_SESSION['role']!='STUDENT'){
    die("Access Denied");
}

include "../config/db.php";

$student_id = $_SESSION['student_id'];
?>

<!DOCTYPE html>
<html>
<head>
<title>My Fee Statement</title>

<style>

body{
font-family:Segoe UI;
background:#f4f6f9;
}

.card{
background:#fff;
padding:20px;
width:90%;
max-width:800px;
margin:20px auto;
border-radius:8px;
box-shadow:0 0 10px rgba(0,0,0,0.1);
}

table{
width:100%;
border-collapse:collapse;
}

th,td{
border:1px solid #ccc;
padding:8px;
text-align:center;
}

th{
background:#eee;
}

.download{
background:#27ae60;
color:#fff;
padding:6px 12px;
text-decoration:none;
border-radius:4px;
font-weight:bold;
}

.download:hover{
background:#1e874b;
}

.back{
display:inline-block;
margin-top:15px;
text-decoration:none;
font-weight:bold;
}

</style>

</head>

<body>

<div class="card">

<h3>My Fee Statement</h3>

<table>

<tr>
<th>Date</th>
<th>Receipt No</th>
<th>Amount</th>
<th>Status</th>
<th>Download Receipt</th>
</tr>

<?php

$q = mysqli_query($conn,"
SELECT payment_id, payment_date, receipt_no, total_amount, status
FROM payment
WHERE student_id='$student_id'
ORDER BY payment_date DESC
");

$total = 0;

while($r=mysqli_fetch_assoc($q)){

$total += $r['total_amount'];

?>

<tr>

<td><?= $r['payment_date'] ?></td>

<td><?= $r['receipt_no'] ?></td>

<td>₹<?= number_format($r['total_amount'],2) ?></td>

<td><?= $r['status'] ?></td>

<td>

<?php if($r['status']=='Paid'){ ?>

<a class="download"
href="my_receipts.php?id=<?= $r['payment_id'] ?>">
Download
</a>

<?php } else { ?>

Pending

<?php } ?>

</td>

</tr>

<?php } ?>

<tr>

<th colspan="2">Total Paid</th>

<th colspan="3">
₹<?= number_format($total,2) ?>
</th>

</tr>

</table>

<br>

<button onclick="window.print()">🖨️ Download / Print Statement</button>

<br><br>

<a href="dashboard.php" class="back">
⬅ Back to Dashboard
</a>

</div>

</body>
</html>