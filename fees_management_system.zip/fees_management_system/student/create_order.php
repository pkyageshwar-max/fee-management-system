<?php
/* =====================================
   DEMO CREATE ORDER FILE
   (Simulation Mode - No Razorpay API)
===================================== */

session_start();

header('Content-Type: application/json');

/* Check Student Login */

if(!isset($_SESSION['student_id'])){

echo json_encode([

"error"=>"Unauthorized Access"

]);

exit;

}

/* Check Amount */

if(!isset($_POST['amount'])){

echo json_encode([

"error"=>"Invalid Amount"

]);

exit;

}

$amount = (float)$_POST['amount'];

if($amount <= 0){

echo json_encode([

"error"=>"Amount must be greater than zero"

]);

exit;

}

/* Generate Demo Order */

$order_id = "order_".time();

/* Response Same Like Razorpay */

echo json_encode([

"key"=>"rzp_demo_key",

"order_id"=>$order_id,

"amount"=>$amount

]);

exit;

?>